<?php

namespace App\Http\Controllers\Api;

use App\Domain\Inventory\WarehouseTransferService;
use App\Http\Controllers\Controller;
use App\Support\FinancialActor;
use App\Support\InventoryAccess;
use App\Support\InventoryDecimal;
use App\Support\TenantContext;
use App\Support\WarehousePresentation;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WarehouseTransferController extends Controller
{
    public function __construct(private readonly WarehouseTransferService $transfers) {}

    public function index(Request $request): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $query = DB::table('warehouse_transfers as t')->join('warehouses as s', 's.id', '=', 't.source_warehouse_id')->join('warehouses as d', 'd.id', '=', 't.destination_warehouse_id')->leftJoin('branches as sb', 'sb.id', '=', 's.branch_id')->leftJoin('branches as db', 'db.id', '=', 'd.branch_id')->where('t.tenant_id', $tenant)->when($request->filled('status'), fn ($q) => $q->where('t.status', $request->string('status')))->when($request->filled('sourceWarehouseId'), fn ($q) => $q->where('t.source_warehouse_id', $request->integer('sourceWarehouseId')))->when($request->filled('destinationWarehouseId'), fn ($q) => $q->where('t.destination_warehouse_id', $request->integer('destinationWarehouseId')))->when($request->filled('search'), fn ($q) => $q->where(fn ($s) => $s->where('t.id', 'like', '%'.$request->string('search').'%')->orWhere('s.name', 'like', '%'.$request->string('search').'%')->orWhere('d.name', 'like', '%'.$request->string('search').'%')))->orderByDesc('t.id')->select('t.*', 's.name as source_name', 's.type as source_type', 's.branch_id as source_branch_id', 'sb.name as source_branch_name', 'd.name as destination_name', 'd.type as destination_type', 'd.branch_id as destination_branch_id', 'db.name as destination_branch_name');
        InventoryAccess::scopeWarehouseBranches($query, $request, 's.branch_id');
        InventoryAccess::scopeWarehouseBranches($query, $request, 'd.branch_id');
        $kpiQuery = clone $query;
        $kpis = ['draft' => (clone $kpiQuery)->where('t.status', 'draft')->count(), 'submitted' => (clone $kpiQuery)->where('t.status', 'submitted')->count(), 'inTransit' => (clone $kpiQuery)->whereIn('t.status', ['dispatched', 'partially_received'])->count(), 'received' => (clone $kpiQuery)->where('t.status', 'received')->count()];
        $paginator = $query->paginate(min(max((int) $request->query('perPage', 25), 1), 100));

        return response()->json(['data' => collect($paginator->items())->map(fn (object $row) => $this->serialize($tenant, $row, false, $request))->values(), 'meta' => ['currentPage' => $paginator->currentPage(), 'perPage' => $paginator->perPage(), 'total' => $paginator->total(), 'lastPage' => $paginator->lastPage(), 'kpis' => $kpis]]);
    }

    public function store(Request $request): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $id = $this->transfers->create($request, $tenant, $this->draftData($request, false), FinancialActor::id($request, $tenant));

        return response()->json(['data' => $this->serialize($tenant, $this->find($tenant, $id), true, $request)], 201);
    }

    public function show(Request $request, int $transfer): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $row = $this->find($tenant, $transfer);
        $this->assertTransferBranchAccess($request, $row);

        return response()->json(['data' => $this->serialize($tenant, $row, true, $request)]);
    }

    public function update(Request $request, int $transfer): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $this->assertTransferBranchAccess($request, $this->find($tenant, $transfer));
        $this->transfers->update($request, $tenant, $transfer, $this->draftData($request, true), FinancialActor::id($request, $tenant));

        return response()->json(['data' => $this->serialize($tenant, $this->find($tenant, $transfer), true, $request)]);
    }

    public function action(Request $request, int $transfer, string $action): JsonResponse
    {
        $tenant = TenantContext::id($request);
        abort_unless(in_array($action, ['submit', 'approve', 'reject', 'dispatch', 'close-shortage', 'cancel'], true), 404);
        $this->assertTransferBranchAccess($request, $this->find($tenant, $transfer));
        $data = $request->validate(['idempotencyKey' => ['required', 'string', 'max:120'], 'rejectionReason' => ['nullable', 'string', 'max:1000'], 'discrepancyReason' => ['nullable', 'string', 'max:1000'], 'cancellationReason' => ['nullable', 'string', 'max:1000']]);
        $this->transfers->action($request, $tenant, $transfer, str_replace('-', '_', $action), $data, FinancialActor::id($request, $tenant));

        return response()->json(['data' => $this->serialize($tenant, $this->find($tenant, $transfer), true, $request)]);
    }

    public function receive(Request $request, int $transfer): JsonResponse
    {
        $data = $request->validate(['idempotencyKey' => ['required', 'string', 'max:120'], 'lines' => ['required', 'array', 'min:1'], 'lines.*.itemId' => ['required', 'integer', 'distinct'], 'lines.*.receivedQuantity' => ['required', 'regex:/^\d+(\.\d{1,3})?$/'], 'lines.*.unit' => ['nullable', 'string', 'max:40'], 'lines.*.discrepancyReason' => ['nullable', 'string', 'max:1000']]);
        $tenant = TenantContext::id($request);
        $this->assertTransferBranchAccess($request, $this->find($tenant, $transfer));
        $this->transfers->receive($request, $tenant, $transfer, $data, FinancialActor::id($request, $tenant));

        return response()->json(['data' => $this->serialize($tenant, $this->find($tenant, $transfer), true, $request)]);
    }

    private function draftData(Request $request, bool $partial): array
    {
        return $request->validate(['sourceWarehouseId' => [$partial ? 'sometimes' : 'required', 'integer'], 'destinationWarehouseId' => [$partial ? 'sometimes' : 'required', 'integer'], 'notes' => ['sometimes', 'nullable', 'string', 'max:4000'], 'idempotencyKey' => [$partial ? 'nullable' : 'required', 'string', 'max:120'], 'lines' => ['sometimes', 'array'], 'lines.*.itemId' => ['required_with:lines', 'integer', 'distinct'], 'lines.*.requestedQuantity' => ['required_with:lines', 'regex:/^\d+(\.\d{1,3})?$/'], 'lines.*.unit' => ['nullable', 'string', 'max:40']]);
    }

    private function find(int $tenant, int $id): object
    {
        $row = DB::table('warehouse_transfers as t')->join('warehouses as s', 's.id', '=', 't.source_warehouse_id')->join('warehouses as d', 'd.id', '=', 't.destination_warehouse_id')->leftJoin('branches as sb', 'sb.id', '=', 's.branch_id')->leftJoin('branches as db', 'db.id', '=', 'd.branch_id')->where('t.tenant_id', $tenant)->where('t.id', $id)->select('t.*', 's.name as source_name', 's.type as source_type', 's.branch_id as source_branch_id', 'sb.name as source_branch_name', 'd.name as destination_name', 'd.type as destination_type', 'd.branch_id as destination_branch_id', 'db.name as destination_branch_name')->first();
        abort_unless($row, 404, 'Transfer not found.');

        return $row;
    }

    private function assertTransferBranchAccess(Request $request, object $transfer): void
    {
        foreach ([$transfer->source_warehouse_id, $transfer->destination_warehouse_id] as $warehouseId) {
            InventoryAccess::assertBranchAccess($request, DB::table('warehouses')->where('id', $warehouseId)->value('branch_id'));
        }
    }

    private function serialize(int $tenant, object $row, bool $detail, Request $request): array
    {
        $status = $row->status;
        $data = ['id' => (int) $row->id, 'number' => 'TR-'.str_pad((string) $row->id, 4, '0', STR_PAD_LEFT), 'sourceWarehouseId' => (int) $row->source_warehouse_id, 'sourceWarehouseName' => WarehousePresentation::displayName($row->source_branch_name, $row->source_type), 'sourceBranchId' => $row->source_branch_id !== null ? (int) $row->source_branch_id : null, 'sourceBranchName' => $row->source_branch_name, 'destinationWarehouseId' => (int) $row->destination_warehouse_id, 'destinationWarehouseName' => WarehousePresentation::displayName($row->destination_branch_name, $row->destination_type), 'destinationBranchId' => $row->destination_branch_id !== null ? (int) $row->destination_branch_id : null, 'destinationBranchName' => $row->destination_branch_name, 'status' => $status, 'notes' => $row->notes, 'rejectionReason' => $row->rejection_reason, 'discrepancyReason' => $row->shortage_reason, 'createdAt' => $row->created_at, 'submittedAt' => $row->submitted_at, 'approvedAt' => $row->approved_at, 'rejectedAt' => $row->rejected_at, 'dispatchedAt' => $row->dispatched_at, 'receivedAt' => $row->received_at, 'closedAt' => $row->closed_at, 'canEdit' => $status === 'draft' && InventoryAccess::allows($request, 'inventory.transfers.edit'), 'canSubmit' => $status === 'draft' && InventoryAccess::allows($request, 'inventory.transfers.submit'), 'canApprove' => $status === 'submitted' && InventoryAccess::allows($request, 'inventory.transfers.approve'), 'canReject' => $status === 'submitted' && InventoryAccess::allows($request, 'inventory.transfers.approve'), 'canDispatch' => $status === 'approved' && InventoryAccess::allows($request, 'inventory.transfers.dispatch'), 'canReceive' => in_array($status, ['dispatched', 'partially_received'], true) && InventoryAccess::allows($request, 'inventory.transfers.receive'), 'canCloseShortage' => in_array($status, ['dispatched', 'partially_received'], true) && InventoryAccess::allows($request, 'inventory.transfers.receive'), 'canCancel' => in_array($status, ['draft', 'submitted', 'approved'], true) && InventoryAccess::allows($request, 'inventory.transfers.cancel')];
        if ($detail) {
            $data['lines'] = DB::table('warehouse_transfer_lines as l')->join('inventory_items as i', 'i.id', '=', 'l.inventory_item_id')->leftJoin('stock_balances as b', fn ($j) => $j->on('b.inventory_item_id', '=', 'l.inventory_item_id')->where('b.tenant_id', $tenant)->where('b.warehouse_id', $row->source_warehouse_id))->where('l.warehouse_transfer_id', $row->id)->get(['l.*', 'i.name_ar', 'i.name_en', 'i.sku', 'b.quantity_on_hand', 'b.reserved_quantity as balance_reserved'])->map(function (object $l) {
                $dis = InventoryDecimal::units($l->dispatched_base_quantity);
                $rec = InventoryDecimal::units($l->received_base_quantity);

                return ['itemId' => (int) $l->inventory_item_id, 'itemName' => $l->name_ar ?: $l->name_en, 'sku' => $l->sku, 'unit' => $l->unit, 'requestedQuantity' => $l->requested_quantity, 'requestedBaseQuantity' => $l->requested_base_quantity, 'reservedQuantity' => $l->reserved_quantity, 'dispatchedQuantity' => $l->dispatched_quantity, 'receivedQuantity' => $l->received_quantity, 'inTransitQuantity' => InventoryDecimal::quantity(max(0, $dis - $rec)), 'discrepancyQuantity' => InventoryDecimal::quantity(max(0, $dis - $rec)), 'discrepancyReason' => $l->discrepancy_reason, 'availableQuantity' => InventoryDecimal::quantity(max(0, InventoryDecimal::signedUnits($l->quantity_on_hand ?? '0') - InventoryDecimal::units($l->balance_reserved ?? '0'))), 'conversionFactor' => $l->requested_conversion_factor];
            })->values();
            $data['auditTimeline'] = DB::table('activity_logs')->leftJoin('users','users.id','=','activity_logs.user_id')->where('activity_logs.tenant_id',$tenant)->where('activity_logs.entity_type','warehouse_transfer')->where('activity_logs.entity_id',$row->id)->orderBy('activity_logs.created_at')->get(['activity_logs.action', 'activity_logs.created_at', 'users.name'])->map(fn (object $a) => ['status' => str_replace('warehouse_transfer.','',$a->action), 'at' => $a->created_at, 'actor' => $a->name])->values();
        }

return $data;
    }
}
