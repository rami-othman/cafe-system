<?php

namespace App\Http\Requests\Api\V1;

use Illuminate\Foundation\Http\FormRequest;

class StockCountRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'branchId' => ['nullable', 'integer'],
            'warehouseId' => ['required', 'integer'],
            'countDate' => ['required', 'date_format:Y-m-d'],
            'countType' => ['nullable', 'in:full,cycle'],
            'categoryFilters' => ['nullable', 'array'],
            'categoryFilters.*' => ['string', 'max:255'],
            'notes' => ['nullable', 'string', 'max:4000'],
        ];
    }
}
