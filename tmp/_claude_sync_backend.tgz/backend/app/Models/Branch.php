<?php

namespace App\Models;

use App\Models\Concerns\HasTenantScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Branch extends Model
{
    use HasTenantScope, SoftDeletes;

    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'receipt_printing_enabled' => 'boolean',
            'auto_print_after_payment' => 'boolean',
            'default_printer_port' => 'integer',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function posInventoryWarehouse(): BelongsTo
    {
        return $this->belongsTo(Warehouse::class, 'pos_inventory_warehouse_id');
    }

    public function warehouses(): HasMany
    {
        return $this->hasMany(Warehouse::class);
    }

    public function menuAssignments(): HasMany
    {
        return $this->hasMany(MenuAssignment::class);
    }
}
