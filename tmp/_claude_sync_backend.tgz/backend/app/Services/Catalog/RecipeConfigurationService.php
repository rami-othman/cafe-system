<?php

namespace App\Services\Catalog;

use App\Domain\Menu\Enums\MenuAuditAction;
use App\Domain\Inventory\RecipeMaterialEligibility;
use App\Domain\Inventory\UnitConversionResolver;
use App\Support\InventoryUnitCatalog;
use App\Models\ModifierOption;
use App\Models\ModifierOptionRecipeProfile;
use App\Models\Product;
use App\Models\ProductRecipe;
use App\Models\ProductVariant;
use App\Models\VariantRecipe;
use Brick\Math\BigDecimal;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class RecipeConfigurationService
{
    public function __construct(private readonly MaterialCatalogService $materials, private readonly RecipeUnitRegistry $units, private readonly UnitConversionResolver $conversions, private readonly CatalogAuditService $audit) {}

    public function recipe(ProductVariant $variant): array
    {
        $state = $this->effectiveRecipe($variant);

        return ['variantId' => $variant->id, 'hasOverride' => $state['hasOverride'], 'source' => $state['source'], 'components' => $state['overrideComponents'], 'overrideComponents' => $state['overrideComponents'], 'effectiveComponents' => $state['effectiveComponents']];
    }

    public function replaceRecipe(ProductVariant $variant, array $components): array
    {
        $this->activeVariant($variant);
        $this->validateComponents($variant->tenant_id, $components, false);

        if ($components === []) {
            return $this->deleteRecipe($variant);
        }

        return DB::transaction(function () use ($variant, $components) {
            $before = $this->recipe($variant);
            $recipe = VariantRecipe::query()
                ->where('tenant_id', $variant->tenant_id)
                ->where('product_variant_id', $variant->id)
                ->lockForUpdate()
                ->first()
                ?? VariantRecipe::query()->create(['tenant_id' => $variant->tenant_id, 'product_variant_id' => $variant->id]);
            $recipe->components()->delete();
            foreach ($components as $c) {
                $recipe->components()->create(['tenant_id' => $variant->tenant_id, 'inventory_item_id' => $c['materialId'], 'quantity' => $c['quantity'], 'unit_code' => $c['unitCode'], 'sort_order' => $c['sortOrder'] ?? 0]);
            } $this->audit->log($variant->tenant_id, $variant, MenuAuditAction::Updated, $before, ['recipeComponents' => count($components)]);

            return $this->recipe($variant->fresh('recipe.components'));
        });
    }

    public function productRecipe(Product $product): array
    {
        $recipe = $product->recipe()->with('components')->first();

        return ['productId' => $product->id, 'configured' => $recipe !== null && $recipe->components->isNotEmpty(), 'components' => $recipe?->components->map(fn ($component) => $this->component($component))->values()->all() ?? []];
    }

    public function replaceProductRecipe(Product $product, array $components): array
    {
        $this->activeProduct($product);
        $this->validateComponents($product->tenant_id, $components, false);

        if ($components === []) {
            return $this->deleteProductRecipe($product);
        }

        return DB::transaction(function () use ($product, $components): array {
            $before = $this->productRecipe($product);
            $recipe = ProductRecipe::query()
                ->where('tenant_id', $product->tenant_id)
                ->where('product_id', $product->id)
                ->lockForUpdate()
                ->first()
                ?? ProductRecipe::query()->create(['tenant_id' => $product->tenant_id, 'product_id' => $product->id]);
            $recipe->components()->delete();
            foreach ($components as $component) {
                $recipe->components()->create(['tenant_id' => $product->tenant_id, 'inventory_item_id' => $component['materialId'], 'quantity' => $component['quantity'], 'unit_code' => $component['unitCode'], 'sort_order' => $component['sortOrder'] ?? 0]);
            }
            $this->audit->log($product->tenant_id, $product, MenuAuditAction::Updated, $before, ['productRecipeComponents' => count($components)]);

            return $this->productRecipe($product->fresh('recipe.components'));
        });
    }

    public function deleteRecipe(ProductVariant $variant): array
    {
        $this->activeVariant($variant);

        return DB::transaction(function () use ($variant): array {
            $recipe = VariantRecipe::query()
                ->where('tenant_id', $variant->tenant_id)
                ->where('product_variant_id', $variant->id)
                ->lockForUpdate()
                ->first();
            if ($recipe !== null) {
                $before = $this->recipe($variant);
                $recipe->delete();
                $this->audit->log($variant->tenant_id, $variant, MenuAuditAction::Updated, $before, ['recipeOverrideRemoved' => true]);
            }

            return $this->recipe($variant->fresh('recipe.components'));
        });
    }

    public function deleteProductRecipe(Product $product): array
    {
        $this->activeProduct($product);

        return DB::transaction(function () use ($product): array {
            $recipe = ProductRecipe::query()
                ->where('tenant_id', $product->tenant_id)
                ->where('product_id', $product->id)
                ->lockForUpdate()
                ->first();
            if ($recipe !== null) {
                $before = $this->productRecipe($product);
                $recipe->delete();
                $this->audit->log($product->tenant_id, $product, MenuAuditAction::Updated, $before, ['productRecipeRemoved' => true]);
            }

            return $this->productRecipe($product->fresh('recipe.components'));
        });
    }

    /** @return array{source: string, hasOverride: bool, overrideComponents: array<int, array<string, mixed>>, effectiveComponents: array<int, array<string, mixed>>} */
    public function effectiveRecipe(ProductVariant $variant): array
    {
        $variant->loadMissing(['recipe.components', 'product.recipe.components']);
        $override = $variant->recipe?->components->sortBy('sort_order')->values();
        $product = $variant->product?->recipe?->components->sortBy('sort_order')->values();
        $overrideComponents = $override?->map(fn ($component) => $this->component($component))->all() ?? [];

        if ($override?->isNotEmpty()) {
            return ['source' => 'variant', 'hasOverride' => true, 'overrideComponents' => $overrideComponents, 'effectiveComponents' => $overrideComponents];
        }
        $effective = $product?->map(fn ($component) => $this->component($component))->all() ?? [];

        return ['source' => $effective === [] ? 'none' : 'product', 'hasOverride' => false, 'overrideComponents' => [], 'effectiveComponents' => $effective];
    }

    /** @return array<int, array{source: string, hasOverride: bool, overrideComponents: array<int, array<string, mixed>>, effectiveComponents: array<int, array<string, mixed>>}> */
    public function effectiveRecipes(iterable $variants): array
    {
        $ids = collect($variants)->pluck('id')->filter()->values();
        if ($ids->isEmpty()) {
            return [];
        }
        $variants = ProductVariant::query()
            ->whereIn('id', $ids)
            ->with(['recipe.components', 'product.recipe.components'])
            ->get();
        $states = [];
        foreach ($variants as $variant) {
            $states[$variant->id] = $this->effectiveRecipe($variant);
        }

        return $states;
    }

    public function profile(ModifierOption $option, ?Product $product = null, ?ProductVariant $variant = null): array
    {
        $this->scope($option, $product, $variant);
        $productId = $variant?->product_id ?? $product?->id;
        $effective = $this->effective($option, $productId, $variant?->id);
        $own = $this->own($option, $productId, $variant?->id);

        return ['optionId' => $option->id, 'scope' => $variant ? 'variant' : ($product ? 'product' : 'global'), 'hasOverride' => $own !== null, 'inheritedFrom' => $own ? null : ($effective?->scope_type ?? null), 'components' => ($own ?? $effective)?->components->sortBy('sort_order')->map(fn ($c) => $this->component($c))->values()->all() ?? []];
    }

    public function replaceProfile(ModifierOption $option, array $components, ?Product $product = null, ?ProductVariant $variant = null): array
    {
        $scope = $this->scope($option, $product, $variant);
        $productId = $variant?->product_id ?? $product?->id;
        $this->validateComponents($option->tenant_id, $components, true);
        if (collect($components)->contains(fn ($c) => $c['operation'] === 'remove') && $this->removeWouldApplyToQuantityEnabledGroup($option, $product, $variant)) {
            throw ValidationException::withMessages(['components' => 'REMOVE adjustments are not allowed for quantity-enabled modifier groups.']);
        }

        return DB::transaction(function () use ($option, $components, $product, $productId, $variant, $scope) {
            $profile = $this->own($option, $productId, $variant?->id) ?? ModifierOptionRecipeProfile::query()->create(['tenant_id' => $option->tenant_id, 'modifier_option_id' => $option->id, 'scope_type' => $scope, 'product_id' => $variant ? null : $product?->id, 'product_variant_id' => $variant?->id]);
            $profile->components()->delete();
            foreach ($components as $c) {
                $profile->components()->create(['tenant_id' => $option->tenant_id, 'inventory_item_id' => $c['materialId'], 'operation' => $c['operation'], 'quantity' => $c['quantity'], 'unit_code' => $c['unitCode'], 'sort_order' => $c['sortOrder'] ?? 0]);
            } $this->audit->log($option->tenant_id, $option, MenuAuditAction::Updated, null, ['recipeProfileScope' => $scope, 'componentCount' => count($components)]);

            return $this->profile($option, $product, $variant);
        });
    }

    public function deleteProfile(ModifierOption $option, ?Product $product = null, ?ProductVariant $variant = null): void
    {
        $this->scope($option, $product, $variant);
        $this->own($option, $variant?->product_id ?? $product?->id, $variant?->id)?->delete();
    }

    public function effective(ModifierOption $option, ?int $productId, ?int $variantId): ?ModifierOptionRecipeProfile
    {
        return ModifierOptionRecipeProfile::query()->where('tenant_id', $option->tenant_id)->where('modifier_option_id', $option->id)->where(fn ($q) => $q->where('scope_type', 'global')->orWhere(fn ($x) => $x->where('scope_type', 'product')->where('product_id', $productId))->orWhere(fn ($x) => $x->where('scope_type', 'variant')->where('product_variant_id', $variantId)))->with('components')->orderByRaw("CASE scope_type WHEN 'variant' THEN 1 WHEN 'product' THEN 2 ELSE 3 END")->first();
    }

    /**
     * Returns the effective profile for every supplied option in a bounded
     * query set. An explicit empty scoped profile remains a real result.
     *
     * @return array<int, ModifierOptionRecipeProfile>
     */
    public function effectiveProfilesFor(int $tenantId, array $optionIds, ?int $productId, ?int $variantId): array
    {
        $optionIds = array_values(array_unique(array_map('intval', $optionIds)));
        if ($optionIds === []) {
            return [];
        }

        $profiles = ModifierOptionRecipeProfile::query()
            ->where('tenant_id', $tenantId)
            ->whereIn('modifier_option_id', $optionIds)
            ->where(function ($query) use ($productId, $variantId): void {
                $query->where('scope_type', 'global')
                    ->orWhere(function ($nested) use ($productId): void {
                        $nested->where('scope_type', 'product')->where('product_id', $productId);
                    })
                    ->orWhere(function ($nested) use ($variantId): void {
                        $nested->where('scope_type', 'variant')->where('product_variant_id', $variantId);
                    });
            })
            ->with('components')
            ->get();

        $rank = ['global' => 1, 'product' => 2, 'variant' => 3];
        $effective = [];
        foreach ($profiles as $profile) {
            $id = (int) $profile->modifier_option_id;
            if (! isset($effective[$id]) || $rank[$profile->scope_type] > $rank[$effective[$id]->scope_type]) {
                $effective[$id] = $profile;
            }
        }

        return $effective;
    }

    /** @return array<int, array<string, mixed>> */
    public function profileSummary(ProductVariant $variant): array
    {
        $this->activeVariant($variant);
        $options = $variant->product->modifierGroups()
            ->where('modifier_groups.is_active', true)
            ->with(['options' => fn ($query) => $query->where('is_active', true)->where('is_available', true)])
            ->get()
            ->flatMap(fn ($group) => $group->options)
            ->filter(fn ($option) => ! $option->trashed())
            ->values();
        $optionIds = $options->pluck('id')->all();
        $effective = $this->effectiveProfilesFor($variant->tenant_id, $optionIds, $variant->product_id, $variant->id);
        $own = ModifierOptionRecipeProfile::query()
            ->where('tenant_id', $variant->tenant_id)
            ->whereIn('modifier_option_id', $optionIds)
            ->where('scope_type', 'variant')
            ->where('product_variant_id', $variant->id)
            ->with('components')
            ->get()
            ->keyBy('modifier_option_id');

        return $options->map(function (ModifierOption $option) use ($effective, $own): array {
            $profile = $own->get($option->id);
            $resolved = $profile ?? $effective[$option->id] ?? null;

            return [
                'optionId' => $option->id,
                'scope' => 'variant',
                'hasOverride' => $profile !== null,
                'inheritedFrom' => $profile ? null : ($resolved?->scope_type ?? null),
                'components' => $resolved?->components->sortBy('sort_order')->map(fn ($component) => $this->component($component))->values()->all() ?? [],
            ];
        })->all();
    }

    /** @return array<int, array<string, mixed>> */
    public function globalProfileSummary(int $tenantId, array $optionIds): array
    {
        if ($optionIds === []) {
            return [];
        }

        return ModifierOptionRecipeProfile::query()
            ->where('tenant_id', $tenantId)
            ->whereIn('modifier_option_id', $optionIds)
            ->where('scope_type', 'global')
            ->with('components')
            ->get()
            ->map(fn (ModifierOptionRecipeProfile $profile): array => [
                'optionId' => (int) $profile->modifier_option_id,
                'scope' => 'global',
                'hasOverride' => true,
                'inheritedFrom' => null,
                'components' => $profile->components
                    ->sortBy('sort_order')
                    ->map(fn ($component) => $this->component($component))
                    ->values()
                    ->all(),
            ])
            ->values()
            ->all();
    }

    private function own(ModifierOption $option, ?int $productId, ?int $variantId): ?ModifierOptionRecipeProfile
    {
        return ModifierOptionRecipeProfile::query()->where('tenant_id', $option->tenant_id)->where('modifier_option_id', $option->id)->when($variantId, fn ($q) => $q->where('scope_type', 'variant')->where('product_variant_id', $variantId), fn ($q) => ($productId ? $q->where('scope_type', 'product')->where('product_id', $productId) : $q->where('scope_type', 'global')))->with('components')->first();
    }

    private function scope(ModifierOption $option, ?Product $product, ?ProductVariant $variant): string
    {
        if ($option->trashed() || ! $option->modifierGroup || $option->modifierGroup->trashed()) {
            throw ValidationException::withMessages(['option' => 'Archived modifier options and groups are read-only.']);
        }
        if ($variant) {
            $product = $variant->product;
            if ($variant->trashed() || ! $product || $product->trashed()) {
                throw ValidationException::withMessages(['variant' => 'Archived variants and products are read-only.']);
            }
            if (! $product || ! $product->modifierGroups()->whereKey($option->modifier_group_id)->exists()) {
                throw ValidationException::withMessages(['option' => 'Option is not assigned to this product.']);
            }

            return 'variant';
        } if ($product) {
            if ($product->trashed()) {
                throw ValidationException::withMessages(['product' => 'Archived products are read-only.']);
            }
            if (! $product->modifierGroups()->whereKey($option->modifier_group_id)->exists()) {
                throw ValidationException::withMessages(['option' => 'Option is not assigned to this product.']);
            }

            return 'product';
        }

        return 'global';
    }

    private function validateComponents(int $tenant, array $components, bool $operations): void
    {
        $seen = [];
        foreach ($components as $i => $c) {
            $id = (int) ($c['materialId'] ?? 0);
            $op = $c['operation'] ?? 'base';
            if (! $id || isset($seen[$id.':'.$op])) {
                throw ValidationException::withMessages(['components' => 'Duplicate or invalid material component.']);
            }$seen[$id.':'.$op] = true;
            $m = $this->materials->material($tenant, $id);
            if (! $m || ! $m->is_active || $m->deleted_at || ! RecipeMaterialEligibility::allows($m) || ! $this->materials->resource($m)['configurationAvailable']) {
                throw ValidationException::withMessages(['components' => 'Material is unavailable, ineligible for recipe consumption, or has an unmapped unit.']);
            } $q = (string) ($c['quantity'] ?? '');
            try {
                $quantity = BigDecimal::of($q);
            } catch (\Throwable) {
                $quantity = BigDecimal::zero();
            }
            if (! preg_match('/^\d+(\.\d{1,6})?$/', $q) || $quantity->isLessThanOrEqualTo(BigDecimal::zero())) {
                throw ValidationException::withMessages(['components' => 'Quantity must be a positive decimal with at most six places.']);
            }
            $u = (string) ($c['unitCode'] ?? '');
            if (! InventoryUnitCatalog::isKnown($u)) {
                throw ValidationException::withMessages(["components.$i.unitCode" => 'Recipe unit is not an Inventory unit.']);
            }
            $this->validateInventoryConversion($tenant, $m, $q, $u, $i);
            if ($operations && ! in_array($op, ['add', 'remove'], true)) {
                throw ValidationException::withMessages(['components' => 'Operation must be add or remove.']);
            }
        }
    }

    private function validateInventoryConversion(int $tenant, object $material, string $quantity, string $unit, int $index): void
    {
        try {
            $this->conversions->resolveRecipe($tenant, $material, $quantity, $unit);
        } catch (ValidationException $exception) {
            $errors = $exception->errors();
            $field = array_key_exists('quantity', $errors) ? 'quantity' : 'unitCode';
            $message = (string) collect($errors)->flatten()->first();

            throw ValidationException::withMessages(["components.$index.$field" => $message]);
        }
    }

    private function component(object $c): array
    {
        return ['materialId' => (int) $c->inventory_item_id, 'quantity' => $this->units->quantityString((string) $c->quantity), 'unitCode' => $c->unit_code, 'operation' => $c->operation ?? null, 'sortOrder' => $c->sort_order];
    }

    private function activeVariant(ProductVariant $v): void
    {
        if ($v->trashed() || ! $v->product || $v->product->trashed()) {
            throw ValidationException::withMessages(['variant' => 'Archived variants are read-only.']);
        }
    }

    private function activeProduct(Product $product): void
    {
        if ($product->trashed()) {
            throw ValidationException::withMessages(['product' => 'Archived products are read-only.']);
        }
    }

    private function effectiveAllowQuantity(Product $p, int $groupId): bool
    {
        $g = $p->modifierGroups()->whereKey($groupId)->first();

        return (bool) ($g?->pivot->allow_quantity_override ?? $g?->allow_quantity);
    }

    private function removeWouldApplyToQuantityEnabledGroup(ModifierOption $option, ?Product $product, ?ProductVariant $variant): bool
    {
        if ($variant) {
            return $this->effectiveAllowQuantity($variant->product, $option->modifier_group_id);
        }
        if ($product) {
            return $this->effectiveAllowQuantity($product, $option->modifier_group_id);
        }

        return DB::table('product_modifier_group')
            ->join('modifier_groups', 'modifier_groups.id', '=', 'product_modifier_group.modifier_group_id')
            ->where('product_modifier_group.modifier_group_id', $option->modifier_group_id)
            ->where(fn ($query) => $query->where('product_modifier_group.allow_quantity_override', true)->orWhere(fn ($nested) => $nested->whereNull('product_modifier_group.allow_quantity_override')->where('modifier_groups.allow_quantity', true)))
            ->exists();
    }
}
