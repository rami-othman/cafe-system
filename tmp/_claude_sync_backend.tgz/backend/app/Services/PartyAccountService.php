<?php

namespace App\Services;

use App\Domain\Customer\CustomerNameNormalizer;
use App\Domain\Customer\CustomerNumberGenerator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\ValidationException;

/** One person record and one ledger account can hold both sales and purchases. */
final class PartyAccountService
{
    public function __construct(private readonly CustomerNumberGenerator $numbers) {}

    public function ensureForCustomer(int $tenantId, int $customerId, ?int $actorId = null): int
    {
        return DB::transaction(function () use ($tenantId, $customerId, $actorId): int {
            $customer = DB::table('customers')->where('tenant_id', $tenantId)
                ->where('id', $customerId)->lockForUpdate()->first();
            abort_unless($customer, 404, 'Customer not found.');
            if ($customer->financial_account_id) return (int) $customer->financial_account_id;
            if ($customer->is_walk_in ?? false) {
                throw ValidationException::withMessages(['customerId' => 'العميل النقدي العام لا يحتاج إلى حساب شخصي.']);
            }
            $parent = DB::table('financial_accounts')->where('tenant_id', $tenantId)
                ->whereIn('code', ['121', '1200'])->whereNull('deleted_at')->where('is_active', true)
                ->orderByRaw("CASE code WHEN '121' THEN 0 ELSE 1 END")->first();
            if (! $parent) {
                $id = DB::table('financial_accounts')->insertGetId([
                    'tenant_id' => $tenantId, 'code' => '1200', 'name_ar' => 'حسابات الأشخاص',
                    'name_en' => 'Party accounts', 'account_group' => 'assets',
                    'normal_balance' => 'debit', 'is_active' => true, 'is_system_protected' => true,
                    'created_at' => now(), 'updated_at' => now(),
                ]);
                $parent = DB::table('financial_accounts')->where('id', $id)->first();
            }
            $payload = [
                'tenant_id' => $tenantId, 'parent_account_id' => $parent->id,
                'code' => 'P'.$customerId, 'name_ar' => $customer->name,
                'name_en' => $customer->name, 'account_group' => $parent->account_group,
                'normal_balance' => $parent->normal_balance, 'is_active' => true,
                'is_system_protected' => true, 'created_by' => $actorId,
                'created_at' => now(), 'updated_at' => now(),
            ];
            if (Schema::hasColumn('financial_accounts', 'catalog_source')) {
                $payload['catalog_source'] = $parent->catalog_source;
            }
            $accountId = (int) DB::table('financial_accounts')->insertGetId($payload);
            DB::table('customers')->where('id', $customerId)->update([
                'financial_account_id' => $accountId, 'updated_at' => now(),
            ]);

            return $accountId;
        });
    }

    public function codeForCustomer(int $tenantId, int $customerId, ?int $actorId = null): string
    {
        $accountId = $this->ensureForCustomer($tenantId, $customerId, $actorId);

        return (string) DB::table('financial_accounts')->where('id', $accountId)->value('code');
    }

    public function customerForSupplier(int $tenantId, int $supplierId, ?int $actorId = null): int
    {
        return DB::transaction(function () use ($tenantId, $supplierId, $actorId): int {
            $supplier = DB::table('suppliers')->where('tenant_id', $tenantId)->where('id', $supplierId)
                ->lockForUpdate()->first();
            abort_unless($supplier, 404, 'Supplier not found.');
            if ($supplier->customer_id) return (int) $supplier->customer_id;
            $name = CustomerNameNormalizer::normalize($supplier->name);
            $customerId = (int) DB::table('customers')->insertGetId([
                'tenant_id' => $tenantId, 'owner_branch_id' => $supplier->owner_branch_id,
                'customer_number' => $this->numbers->next($tenantId),
                'name' => $name['displayName'], 'normalized_name' => $name['normalizedName'],
                'phone' => $supplier->phone, 'email' => $supplier->email,
                'customer_type' => 'registered', 'is_walk_in' => false,
                'is_active' => true, 'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->ensureForCustomer($tenantId, $customerId, $actorId);
            DB::table('suppliers')->where('id', $supplierId)->update(['customer_id' => $customerId, 'updated_at' => now()]);

            return $customerId;
        });
    }

    public function codeForSupplier(int $tenantId, int $supplierId, ?int $actorId = null): string
    {
        return $this->codeForCustomer($tenantId, $this->customerForSupplier($tenantId, $supplierId, $actorId), $actorId);
    }
}
