<?php

namespace App\Services;

use App\Domain\Customer\CustomerNameNormalizer;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class CustomerManagementService
{
    public function __construct(private readonly PartyAccountService $partyAccounts) {}

    public function create(int $tenantId, int $actorId, array $data, ?\Illuminate\Http\Request $request = null): object
    {
        return DB::transaction(function () use ($tenantId, $actorId, $data, $request): object {
            DB::table('tenants')->where('id', $tenantId)->lockForUpdate()->first();
            $next = (int) DB::table('customers')->where('tenant_id', $tenantId)->count() + 1;
            $normalizedName = CustomerNameNormalizer::normalize($data['name']);
            $id = DB::table('customers')->insertGetId([
                ...($request ? \App\Support\InternalCounterparty::values($request, $tenantId, 'customer', \App\Support\DataScope::resolve($request), $data) : []),
                'tenant_id' => $tenantId,
'owner_branch_id' => $request ? \App\Support\DataScope::resolve($request) : null,
                'customer_number' => sprintf('CUS-%06d', $next),
                'name' => $data['name'], 'customer_type' => 'registered',
                'normalized_name' => $normalizedName['normalizedName'],
                'phone' => $data['phone'] ?? null, 'email' => $data['email'] ?? null,
                'tax_number' => $data['taxNumber'] ?? null,
                'default_credit_terms_days' => $data['defaultCreditTermsDays'] ?? 0,
                'notes' => $data['notes'] ?? null, 'total_spent' => 0, 'visits_count' => 0,
                'is_active' => true, 'is_walk_in' => false, 'is_system_protected' => false,
                'created_by' => $actorId, 'updated_by' => $actorId, 'created_at' => now(), 'updated_at' => now(),
            ]);
            $this->partyAccounts->ensureForCustomer($tenantId, (int) $id, $actorId);
            return $this->find($tenantId, $id);
        });
    }

    public function update(int $tenantId, int $customerId, int $actorId, array $data): object
    {
        $customer = $this->find($tenantId, $customerId);
        if ($customer->is_system_protected && array_key_exists('isActive', $data) && ! $data['isActive']) {
            throw ValidationException::withMessages(['isActive' => 'The protected walk-in customer must remain active.']);
        }
        $values = [];
        if (array_key_exists('isInternal', $data) || array_key_exists('internalBranchId', $data)) {
            $request = request();
            $values += \App\Support\InternalCounterparty::values($request, $tenantId, 'customer', $customer->owner_branch_id ? (int) $customer->owner_branch_id : null, $data);
        }
        foreach (['name' => 'name', 'phone' => 'phone', 'email' => 'email', 'taxNumber' => 'tax_number', 'notes' => 'notes', 'defaultCreditTermsDays' => 'default_credit_terms_days', 'isActive' => 'is_active'] as $input => $column) {
            if (array_key_exists($input, $data)) $values[$column] = $data[$input];
        }
        if (array_key_exists('name', $data)) {
            $values['normalized_name'] = CustomerNameNormalizer::normalize($data['name'])['normalizedName'];
        }
        if ($values !== []) DB::transaction(function () use ($tenantId, $customerId, $customer, $actorId, $values): void {
            DB::table('customers')->where('tenant_id', $tenantId)->where('id', $customerId)->update($values + ['updated_by' => $actorId, 'updated_at' => now()]);
            if (isset($values['name']) && $customer->financial_account_id) {
                DB::table('financial_accounts')->where('tenant_id', $tenantId)->where('id', $customer->financial_account_id)
                    ->update(['name_ar' => $values['name'], 'name_en' => $values['name'], 'updated_at' => now()]);
            }
        });
        return $this->find($tenantId, $customerId);
    }

    public function find(int $tenantId, int $customerId): object
    {
        $customer = DB::table('customers')->where('tenant_id', $tenantId)->where('id', $customerId)->whereNull('deleted_at')->first();
        abort_unless($customer, 404, 'Customer not found.');
        return $customer;
    }
}
