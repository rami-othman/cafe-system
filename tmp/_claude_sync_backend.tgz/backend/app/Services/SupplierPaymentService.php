<?php

namespace App\Services;

use App\Support\FinancialActor;
use App\Support\IdempotencyFingerprint;
use App\Support\Money;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * A Supplier Payment records real money already leaving the business, so —
 * unlike a Supplier Invoice — it is created and posted in one atomic step
 * (the same shape as CashTransferService). Phase 5 requires full allocation
 * of the payment amount to open invoices (see docs §17): there is no concept
 * of unallocated supplier credit yet, so nothing is silently lost — an
 * unallocated remainder is rejected outright rather than accepted and
 * forgotten.
 */
class SupplierPaymentService
{
    public function __construct(
        private readonly AccountingPostingService $posting,
        private readonly JournalEntryService $entries,
        private readonly SupplierPayableQueryService $payable,
        private readonly OperationalAuditService $audit,
        private readonly CashSourceResolver $cashSources,
        private readonly PartyAccountService $partyAccounts,
    ) {}

    public function pay(Request $request, int $tenantId, array $data, ?int $actorId, ?object $trustedCashSource = null): object
    {
        $key = $data['idempotencyKey'];
        $fingerprint = IdempotencyFingerprint::from($data);
        if (($existing = $this->byKey($tenantId, $key)) !== null) {
            $this->assertFingerprint($existing, $fingerprint);

            return $existing;
        }

        try {
            return DB::transaction(function () use ($request, $tenantId, $data, $actorId, $key, $fingerprint, $trustedCashSource): object {
                $existing = $this->byKey($tenantId, $key, true);
                if ($existing !== null) {
                    $this->assertFingerprint($existing, $fingerprint);

                    return $existing;
                }

                $data = \App\Support\FactoryCurrency::normalize($tenantId, $data, 'payment');
                $supplier = DB::table('suppliers')->where('tenant_id', $tenantId)->where('id', $data['supplierId'])->where('is_active', true)->whereNull('deleted_at')->first();
                \App\Support\DataScope::assertReference($tenantId, 'suppliers', (int) $data['supplierId'], isset($data['branchId']) ? (int) $data['branchId'] : null);
                if (! $supplier) {
                    throw ValidationException::withMessages(['supplierId' => 'اختر مورداً نشطاً تابعاً لهذا المستأجر.']);
                }
                if (! empty($data['branchId'])) {
                    FinancialActor::assertBranchAccess($actorId, $tenantId, (int) $data['branchId']);
                }

                $method = DB::table('payment_methods')->where('tenant_id', $tenantId)->where('id', $data['paymentMethodId'])->where('is_active', true)->lockForUpdate()->first();
                $cashSource = null;
                if ($method?->type === 'cash') {
                    if (empty($data['branchId'])) throw ValidationException::withMessages(['branchId' => 'يجب تحديد الفرع للدفع النقدي.']);
                    $cashSource = $trustedCashSource ?? $this->cashSources->resolve(
                        $tenantId, (int) $actorId, (int) $data['branchId'], $data['financialLocationId'] ?? null, true,
                    );
                    $data['financialLocationId'] = (int) $cashSource->location->id;
                    $data['shiftId'] = $cashSource->shift?->id;
                }
                $location = DB::table('financial_locations as l')->join('financial_accounts as a', 'a.id', '=', 'l.financial_account_id')
                    ->where('l.tenant_id', $tenantId)->where('l.id', $data['financialLocationId'])->where('l.is_active', true)
                    ->where('a.is_active', true)->whereNull('a.deleted_at')->select('l.*', 'a.code as account_code')->lockForUpdate()->first();
                if (! $method || ! $location || ($method->type === 'cash'
                    ? $location->kind !== 'cash'
                    : (int) $method->financial_account_id !== (int) $location->financial_account_id)) {
                    throw ValidationException::withMessages(['payment' => 'اختر طريقة دفع نشطة وحساب نقد أو بنك مطابقاً لهذا المستأجر.']);
                }
                if ($location->branch_id && (int) $location->branch_id !== (int) ($data['branchId'] ?? 0)) {
                    throw ValidationException::withMessages(['financialLocationId' => 'الموقع المالي لا يتبع فرع الدفع.']);
                }

                $amountCents = Money::cents($data['amount']);
                if ($amountCents <= 0) {
                    throw ValidationException::withMessages(['amount' => 'يجب أن يكون المبلغ أكبر من الصفر.']);
                }

                $allocations = collect($data['allocations'] ?? [])
                    ->map(fn (array $line) => ['invoiceId' => (int) $line['invoiceId'], 'amountCents' => Money::cents($line['amount'])])
                    ->sortBy('invoiceId')->values();
                if ($allocations->isEmpty()) {
                    throw ValidationException::withMessages(['allocations' => 'يجب توزيع الدفعة على فاتورة واحدة على الأقل.']);
                }
                if ($allocations->pluck('invoiceId')->unique()->count() !== $allocations->count()) {
                    throw ValidationException::withMessages(['allocations' => 'لا يمكن توزيع الدفعة على الفاتورة نفسها مرتين.']);
                }
                $allocatedTotalCents = $allocations->sum('amountCents');
                if ($allocatedTotalCents !== $amountCents) {
                    throw ValidationException::withMessages(['allocations' => 'يجب أن يساوي مجموع التوزيعات مبلغ الدفعة تماماً.']);
                }

                foreach ($allocations as $line) {
                    if ($line['amountCents'] <= 0) {
                        throw ValidationException::withMessages(['allocations' => 'يجب أن يكون كل مبلغ موزّع أكبر من الصفر.']);
                    }
                    $invoice = DB::table('supplier_invoices')->where('tenant_id', $tenantId)->where('id', $line['invoiceId'])->lockForUpdate()->first();
                    if (! $invoice || (int) $invoice->supplier_id !== (int) $supplier->id) {
                        throw ValidationException::withMessages(['allocations' => "الفاتورة رقم {$line['invoiceId']} لا تتبع المورد المحدد."]);
                    }
                    if (! in_array($invoice->status, ['posted', 'partially_paid'], true)) {
                        throw ValidationException::withMessages(['allocations' => "الفاتورة {$invoice->internal_reference} غير متاحة للدفع."]);
                    }
                    $remainingCents = $this->payable->invoiceRemainingCents($tenantId, $invoice->id, lock: true);
                    if ($line['amountCents'] > $remainingCents) {
                        throw ValidationException::withMessages(['allocations' => "المبلغ الموزّع على {$invoice->internal_reference} يتجاوز الرصيد المتبقي ".Money::decimal($remainingCents).'.']);
                    }
                }

                $now = now();
                $paymentId = DB::table('supplier_payments')->insertGetId(\App\Support\FactoryCurrency::columns($data) + [
                    'tenant_id' => $tenantId,
                    'branch_id' => $data['branchId'] ?? null,
                    'supplier_id' => $supplier->id,
                    'payment_number' => \App\Support\DataScope::documentNumber($tenantId, isset($data['branchId']) ? (int) $data['branchId'] : null, $this->nextNumber($tenantId)),
                    'payment_date' => $data['paymentDate'],
                    'amount' => Money::decimal($amountCents),
                    'payment_method_id' => $method->id,
                    'financial_location_id' => $location->id,
                    'shift_id' => $data['shiftId'] ?? null,
                    'external_reference' => $data['externalReference'] ?? null,
                    'notes' => $data['notes'] ?? null,
                    'status' => 'posted',
                    'idempotency_key' => $key,
                    'idempotency_fingerprint' => $fingerprint,
                    'created_by' => $actorId,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);

                foreach ($allocations as $line) {
                    DB::table('payment_allocations')->insert([
                        'tenant_id' => $tenantId,
                        'supplier_payment_id' => $paymentId,
                        'supplier_invoice_id' => $line['invoiceId'],
                        'amount' => Money::decimal($line['amountCents']),
                        'created_at' => $now,
                        'updated_at' => $now,
                    ]);
                    $this->recomputeInvoiceStatus($tenantId, $line['invoiceId']);
                }

                $journalId = $this->posting->postSupplierPayment($request, $tenantId, [
                    'branchId' => $data['branchId'] ?? null,
                    'sourceId' => $paymentId,
                    'sourceEvent' => 'SUPPLIER_PAYMENT_POSTED',
                    'entryDate' => $data['paymentDate'],
                    'description' => "دفعة مورد — {$supplier->name}",
                    'lines' => [
                        ['accountCode' => $this->partyAccounts->codeForSupplier($tenantId, (int) $supplier->id, $actorId), 'debit' => Money::decimal($amountCents), 'credit' => '0.00'],
                        ['accountCode' => $location->account_code, 'debit' => '0.00', 'credit' => Money::decimal($amountCents), 'financialLocationId' => $location->id],
                    ],
                ], $actorId);

                DB::table('supplier_payments')->where('id', $paymentId)->update(['journal_entry_id' => $journalId, 'updated_at' => now()]);
                if ($cashSource?->shift) {
                    DB::table('shift_cash_movements')->insertOrIgnore([
                        'tenant_id' => $tenantId, 'branch_id' => $data['branchId'], 'shift_id' => $cashSource->shift->id,
                        'kind' => 'expense', 'amount' => Money::decimal($amountCents),
                        'description' => "دفعة مورد {$paymentId}", 'source_type' => 'supplier_payment',
                        'source_id' => $paymentId, 'created_by' => $actorId, 'created_at' => now(), 'updated_at' => now(),
                    ]);
                }
                $result = $this->find($tenantId, $paymentId);
                $this->audit->record($request, $tenantId, 'supplier_payment.posted', 'supplier_payment', $paymentId, [], (array) $result, $result->branch_id, $actorId);

                return $result;
            });
        } catch (QueryException $exception) {
            $existing = $this->byKey($tenantId, $key);
            if ($existing !== null) {
                $this->assertFingerprint($existing, $fingerprint);

                return $existing;
            }
            throw $exception;
        }
    }

    public function reverse(Request $request, int $tenantId, int $id, ?int $actorId): object
    {
        return DB::transaction(function () use ($request, $tenantId, $id, $actorId): object {
            $payment = $this->find($tenantId, $id, true);
            if (! empty($payment->branch_id)) {
                FinancialActor::assertBranchAccess($actorId, $tenantId, (int) $payment->branch_id);
            }
            if ($payment->status !== 'posted' || ! $payment->journal_entry_id) {
                throw ValidationException::withMessages(['status' => 'يمكن عكس دفعة مورد مرحّلة وغير معكوسة فقط.']);
            }

            $allocations = DB::table('payment_allocations')->where('tenant_id', $tenantId)->where('supplier_payment_id', $id)->orderBy('supplier_invoice_id')->lockForUpdate()->get();
            foreach ($allocations as $allocation) {
                DB::table('supplier_invoices')->where('tenant_id', $tenantId)->where('id', $allocation->supplier_invoice_id)->lockForUpdate()->first();
            }

            $reversal = $this->entries->reverse($request, $tenantId, (int) $payment->journal_entry_id, $actorId);
            $now = now();
            foreach ($allocations as $allocation) {
                DB::table('supplier_payment_allocation_history')->updateOrInsert(
                    ['supplier_payment_id' => $id, 'supplier_invoice_id' => $allocation->supplier_invoice_id],
                    ['tenant_id' => $tenantId, 'amount' => $allocation->amount, 'payment_date' => $payment->payment_date, 'reversed_at' => $now, 'updated_at' => $now, 'created_at' => $now],
                );
            }
            DB::table('payment_allocations')->where('tenant_id', $tenantId)->where('supplier_payment_id', $id)->delete();
            DB::table('supplier_payments')->where('tenant_id', $tenantId)->where('id', $id)->update([
                'status' => 'reversed', 'reversal_journal_entry_id' => $reversal, 'reversed_by' => $actorId, 'reversed_at' => $now, 'updated_at' => $now,
            ]);
            if ($payment->finance_document_id) {
                DB::table('finance_documents')->where('tenant_id', $tenantId)->where('id', $payment->finance_document_id)->update([
                    'status' => 'reversed', 'reversal_journal_entry_id' => $reversal, 'reversed_by' => $actorId,
                    'reversed_at' => $now, 'reversal_reason' => 'Linked supplier payment reversed.', 'updated_at' => $now,
                ]);
            }
            if ($payment->shift_id) {
                DB::table('shift_cash_movements')->insertOrIgnore([
                    'tenant_id' => $tenantId, 'branch_id' => $payment->branch_id, 'shift_id' => $payment->shift_id,
                    'kind' => 'deposit', 'amount' => $payment->amount,
                    'description' => "عكس دفعة المورد {$payment->payment_number}",
                    'source_type' => 'supplier_payment_reversal', 'source_id' => $payment->id,
                    'created_by' => $actorId, 'created_at' => $now, 'updated_at' => $now,
                ]);
            }
            foreach ($allocations as $allocation) {
                $this->recomputeInvoiceStatus($tenantId, (int) $allocation->supplier_invoice_id);
            }
            $result = $this->find($tenantId, $id);
            $this->audit->record($request, $tenantId, 'supplier_payment.reversed', 'supplier_payment', $id, (array) $payment, (array) $result, $result->branch_id, $actorId);

            return $result;
        });
    }

    public function find(int $tenantId, int $id, bool $lock = false): object
    {
        $query = DB::table('supplier_payments')->where('tenant_id', $tenantId)->where('id', $id);
        if ($lock) {
            $query->lockForUpdate();
        }
        $row = $query->first();
        abort_unless($row, 404, 'دفعة المورد غير موجودة.');

        return $row;
    }

    private function recomputeInvoiceStatus(int $tenantId, int $invoiceId): void
    {
        $invoice = DB::table('supplier_invoices')->where('tenant_id', $tenantId)->where('id', $invoiceId)->first();
        if (! $invoice || ! in_array($invoice->status, ['posted', 'partially_paid', 'paid'], true)) {
            return;
        }
        $remainingCents = $this->payable->invoiceRemainingCents($tenantId, $invoiceId);
        $totalCents = Money::cents($invoice->total_amount);
        $status = $remainingCents <= 0 ? 'paid' : ($remainingCents < $totalCents ? 'partially_paid' : 'posted');
        DB::table('supplier_invoices')->where('tenant_id', $tenantId)->where('id', $invoiceId)->update(['status' => $status, 'updated_at' => now()]);
    }

    private function byKey(int $tenantId, string $key, bool $lock = false): ?object
    {
        $query = DB::table('supplier_payments')->where('tenant_id', $tenantId)->where('idempotency_key', $key);
        if ($lock) {
            $query->lockForUpdate();
        }

        return $query->first();
    }

    private function assertFingerprint(object $payment, string $fingerprint): void
    {
        if (! $payment->idempotency_fingerprint || ! hash_equals($payment->idempotency_fingerprint, $fingerprint)) {
            abort(409, 'تم استخدام مفتاح العملية هذا مسبقًا لطلب دفعة مورد مختلفة.');
        }
    }

    private function nextNumber(int $tenantId): string
    {
        $last = DB::table('supplier_payments')->where('tenant_id', $tenantId)->lockForUpdate()->orderByDesc('id')->value('payment_number');
        $number = $last && preg_match('/(\d+)$/', $last, $match) ? ((int) $match[1] + 1) : 1;

        return 'SPAY-'.str_pad((string) $number, 6, '0', STR_PAD_LEFT);
    }
}
