<?php

namespace App\Support;

use App\Models\User;
use App\Services\DefaultTenantRoleService;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * Single authorization boundary for tenant inventory operations.
 *
 * Tenant users currently have the roles seeded by TenantAccessSeeder. Keep the
 * role-to-ability mapping here so controllers do not grow independent checks.
 */
final class InventoryAccess
{
    /** @var array<string, list<string>> */
    private const ROLE_PERMISSIONS = [
        'owner' => ['*'],
        // factory_manager (Phase 2 gap fix, 26/09/2026): the Manufacturing
        // "materials" and "stock counts" tabs both go through the shared
        // Inventory API (InventoryItemController/StockCountController), so
        // without this the factory user got a 403 on every inventory call.
        // No inventory.locations.manage (warehouse creation stays Owner-only)
        // and no inventory.transfers.* (branch-to-branch transfers are
        // banned for the factory by Decision 3 — it is a supplier, not a
        // transfer partner).
        DefaultTenantRoleService::FACTORY_MANAGER => [
            'inventory.view',
            'inventory.items.manage',
            'inventory.counts.view',
            'inventory.counts.create',
            'inventory.counts.post',
            'inventory.adjustments.create',
        ],
        'manager' => [
            'inventory.view',
            'inventory.items.manage',
            'inventory.locations.manage',
            'inventory.transfers.view',
            'inventory.transfers.create',
            'inventory.transfers.edit',
            'inventory.transfers.submit',
            'inventory.transfers.approve',
            'inventory.transfers.dispatch',
            'inventory.transfers.receive',
            'inventory.transfers.cancel',
            'inventory.counts.view',
            'inventory.counts.create',
            'inventory.counts.post',
            'inventory.adjustments.create',
        ],
        // Own-shift bar checks are authorized separately by BarCheckAccess.
        // The full inventory API is not part of the cashier surface.
        'employee' => [],
    ];

    public static function authorize(Request $request, string $permission): void
    {
        $actor = self::actor($request);
        $permissions = self::ROLE_PERMISSIONS[$actor->effectiveRoleCode()] ?? [];

        if (! in_array('*', $permissions, true) && ! in_array($permission, $permissions, true)) {
            throw new HttpException(403, 'You do not have permission to perform this inventory action.');
        }
    }

    /** Allows API resources to expose action availability without making the
     * client a security boundary. The middleware still authorizes every call. */
    public static function allows(Request $request, string $permission): bool
    {
        $actor = self::actor($request);
        $permissions = self::ROLE_PERMISSIONS[$actor->effectiveRoleCode()] ?? [];

        return in_array('*', $permissions, true) || in_array($permission, $permissions, true);
    }

    public static function actor(Request $request): object
    {
        $tenantId = (int) $request->attributes->get('tenant_id', 0);
        $authenticated = $request->attributes->get('auth_user');
        $userId = $authenticated instanceof User ? (int) $authenticated->id : 0;

        if ($tenantId <= 0 || $userId <= 0) {
            throw new HttpException(401, 'Unauthenticated.');
        }

        $user = User::query()->with('tenantRole')
            ->where('tenant_id', $tenantId)
            ->where('id', $userId)
            ->where('is_active', true)
            ->first();

        if (! $user) {
            throw new HttpException(401, 'Unauthenticated.');
        }

        return $user;
    }

    /**
     * An empty array means the actor is not assigned to an active branch.
     *
     * @return list<int>
     */
    public static function allowedBranchIds(Request $request): array
    {
        $actor = self::actor($request);
        return app(\App\Services\BranchAccessService::class)->accessibleBranchIds($actor);
    }

    /** There is no "central"/branchless warehouse concept — every warehouse belongs to a branch. */
    public static function scopeWarehouseBranches(Builder $query, Request $request, string $branchColumn): void
    {
        $query->whereIn($branchColumn, self::allowedBranchIds($request));
    }

    public static function assertBranchAccess(Request $request, ?int $branchId): void
    {
        if ($branchId !== null && in_array($branchId, self::allowedBranchIds($request), true)) {
            return;
        }

        throw new HttpException(403, 'The selected branch is not assigned to this user.');
    }
}
