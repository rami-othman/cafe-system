<?php

namespace App\Services;

use App\Domain\Customer\CustomerNameNormalizer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class FinancialSetupService
{
    /**
     * Read-only readiness check used by the dashboard. It reports only missing
     * configuration that prevents financial posting or materially degrades it;
     * it does not invent a second setup model.
     */
    public function financeReadiness(int $tenantId): array
    {
        $requiredCodes = collect($this->defaultAccounts())->pluck('code')->all();
        $activeCodes = DB::table('financial_accounts')->where('tenant_id', $tenantId)->where('is_active', true)->whereNull('deleted_at')->pluck('code')->all();
        $missingAccounts = array_values(array_diff($requiredCodes, $activeCodes));

        $issues = [];
        if ($missingAccounts !== []) {
            $issues[] = ['code' => 'REQUIRED_ACCOUNTS_MISSING', 'severity' => 'critical', 'accountCodes' => $missingAccounts];
        }

        $locations = DB::table('financial_locations')->where('tenant_id', $tenantId)->where('is_active', true)->pluck('id')->all();
        if ($locations === []) {
            $issues[] = ['code' => 'CASH_BANK_DESTINATION_MISSING', 'severity' => 'critical', 'accountCodes' => []];
        }

        $invalidBranchIds = DB::table('branches as b')->leftJoin('financial_locations as l', function ($join): void {
            $join->on('l.id', '=', 'b.pos_cash_financial_location_id')
                ->on('l.tenant_id', '=', 'b.tenant_id')->on('l.branch_id', '=', 'b.id');
        })->leftJoin('financial_accounts as a', function ($join): void {
            $join->on('a.id', '=', 'l.financial_account_id')->on('a.tenant_id', '=', 'b.tenant_id');
        })->where('b.tenant_id', $tenantId)->where('b.is_active', true)->whereNull('b.deleted_at')
            ->where(fn ($q) => $q->whereNull('l.id')->orWhere('l.is_active', false)
                ->orWhere('l.kind', '!=', 'cash')->orWhere('l.type', '!=', 'cash_drawer')
                ->orWhereNull('a.id')->orWhere('a.is_active', false)->orWhereNotNull('a.deleted_at'))
            ->pluck('b.id')->all();
        if ($invalidBranchIds !== []) {
            $issues[] = ['code' => 'BRANCH_CASH_DRAWER_INVALID', 'severity' => 'critical', 'branchIds' => $invalidBranchIds];
        }

        $invalidMethods = DB::table('payment_methods as methods')
            ->leftJoin('financial_accounts as accounts', 'accounts.id', '=', 'methods.financial_account_id')
            ->leftJoin('financial_locations as locations', 'locations.id', '=', 'methods.financial_location_id')
            ->where('methods.tenant_id', $tenantId)->where('methods.is_active', true)
            ->where(function ($query): void {
                $query->whereNull('accounts.id')->orWhere('accounts.is_active', false)
                    ->orWhere(function ($location): void {
                        $location->whereNotNull('methods.financial_location_id')->where(function ($q): void {
                            $q->whereNull('locations.id')->orWhere('locations.is_active', false);
                        });
                    });
            })->get(['methods.code']);
        if ($invalidMethods->isNotEmpty()) {
            $issues[] = ['code' => 'PAYMENT_DESTINATION_INVALID', 'severity' => 'warning', 'paymentMethodCodes' => $invalidMethods->pluck('code')->values()->all()];
        }

        return ['ready' => $issues === [], 'issues' => $issues];
    }

    /** @return array<int, array<string, string|bool>> */
    public function defaultAccounts(): array
    {
        return [
            ['code' => '1010', 'name_ar' => 'صندوق نقطة البيع', 'name_en' => 'Cash Drawer', 'account_group' => 'assets', 'normal_balance' => 'debit'],
            ['code' => '1020', 'name_ar' => 'الخزنة الرئيسية', 'name_en' => 'Main Safe', 'account_group' => 'assets', 'normal_balance' => 'debit'],
            ['code' => '1030', 'name_ar' => 'الحساب البنكي', 'name_en' => 'Bank Account', 'account_group' => 'assets', 'normal_balance' => 'debit'],
            ['code' => '1040', 'name_ar' => 'صندوق الشام كاش', 'name_en' => 'Sham Cash Box', 'account_group' => 'assets', 'normal_balance' => 'debit'],
            ['code' => '1100', 'name_ar' => 'أصل المخزون', 'name_en' => 'Inventory Asset', 'account_group' => 'assets', 'normal_balance' => 'debit'],
            ['code' => '1200', 'name_ar' => 'الذمم المدينة', 'name_en' => 'Accounts Receivable', 'account_group' => 'assets', 'normal_balance' => 'debit'],
            ['code' => '1500', 'name_ar' => 'الأصول الثابتة', 'name_en' => 'Fixed Assets', 'account_group' => 'assets', 'normal_balance' => 'debit'],
            ['code' => '1590', 'name_ar' => 'مجمع الإهلاك', 'name_en' => 'Accumulated Depreciation', 'account_group' => 'assets', 'normal_balance' => 'credit'],
            ['code' => '2000', 'name_ar' => 'الذمم الدائنة – الموردون', 'name_en' => 'Accounts Payable', 'account_group' => 'liabilities', 'normal_balance' => 'credit'],
            ['code' => '2010', 'name_ar' => 'ضريبة المبيعات المستحقة', 'name_en' => 'Sales Tax Payable', 'account_group' => 'liabilities', 'normal_balance' => 'credit'],
            ['code' => '2020', 'name_ar' => 'أرصدة دائنة للعملاء', 'name_en' => 'Customer Credit Balance', 'account_group' => 'liabilities', 'normal_balance' => 'credit'],
            ['code' => '3000', 'name_ar' => 'حقوق الملكية', 'name_en' => 'Equity', 'account_group' => 'equity', 'normal_balance' => 'credit'],
            ['code' => '4000', 'name_ar' => 'إيرادات المبيعات', 'name_en' => 'Sales Revenue', 'account_group' => 'revenue', 'normal_balance' => 'credit'],
            ['code' => '4010', 'name_ar' => 'الخصومات الممنوحة', 'name_en' => 'Discounts Given', 'account_group' => 'revenue', 'normal_balance' => 'debit'],
            ['code' => '4020', 'name_ar' => 'مرتجعات المبيعات', 'name_en' => 'Sales Returns', 'account_group' => 'revenue', 'normal_balance' => 'debit'],
            ['code' => '4030', 'name_ar' => 'إيرادات الخدمات والرسوم', 'name_en' => 'Service and Charge Revenue', 'account_group' => 'revenue', 'normal_balance' => 'credit'],
            ['code' => '4040', 'name_ar' => 'زيادة الصندوق', 'name_en' => 'Cash Overage', 'account_group' => 'revenue', 'normal_balance' => 'credit'],
            ['code' => '5000', 'name_ar' => 'تكلفة البضاعة المباعة', 'name_en' => 'Cost of Goods Sold', 'account_group' => 'cost_of_sales', 'normal_balance' => 'debit'],
            ['code' => '5010', 'name_ar' => 'هدر وفروقات المخزون', 'name_en' => 'Waste / Inventory Variance', 'account_group' => 'cost_of_sales', 'normal_balance' => 'debit'],
            ['code' => '6100', 'name_ar' => 'مصروف الإيجار', 'name_en' => 'Rent Expense', 'account_group' => 'expenses', 'normal_balance' => 'debit'],
            ['code' => '6110', 'name_ar' => 'مصروف الرواتب', 'name_en' => 'Salaries Expense', 'account_group' => 'expenses', 'normal_balance' => 'debit'],
            ['code' => '6120', 'name_ar' => 'مصروف الخدمات', 'name_en' => 'Utilities Expense', 'account_group' => 'expenses', 'normal_balance' => 'debit'],
            ['code' => '6130', 'name_ar' => 'مصروف الصيانة', 'name_en' => 'Maintenance Expense', 'account_group' => 'expenses', 'normal_balance' => 'debit'],
            ['code' => '6140', 'name_ar' => 'مصروف التسويق', 'name_en' => 'Marketing Expense', 'account_group' => 'expenses', 'normal_balance' => 'debit'],
            ['code' => '6180', 'name_ar' => 'عجز الصندوق', 'name_en' => 'Cash Shortage', 'account_group' => 'expenses', 'normal_balance' => 'debit'],
            ['code' => '6190', 'name_ar' => 'مصروفات متنوعة', 'name_en' => 'Miscellaneous Expense', 'account_group' => 'expenses', 'normal_balance' => 'debit'],
        ];
    }

    public function ensureForTenant(int $tenantId, ?int $initialBranchId = null, ?int $actorId = null, ?string $warehouseName = null): void
    {
        if (! DB::table('tenants')->where('id', $tenantId)->exists()) {
            throw new \RuntimeException("FinancialSetupService::ensureForTenant called with unknown tenant_id [{$tenantId}]. Ensure the tenant is created and committed before seeding its financial accounts.");
        }

        DB::transaction(function () use ($tenantId, $initialBranchId, $actorId, $warehouseName): void {
            $now = now();
            foreach ($this->defaultAccounts() as $account) {
                $existingNames = DB::table('financial_accounts')->where('tenant_id', $tenantId)->where('code', $account['code'])->first(['name_ar', 'name_en']);
                if ($existingNames) {
                    $account['name_ar'] = $existingNames->name_ar;
                    $account['name_en'] = $existingNames->name_en;
                }
                DB::table('financial_accounts')->updateOrInsert(
                    ['tenant_id' => $tenantId, 'code' => $account['code']],
                    $account + ['is_active' => true, 'is_system_protected' => true, 'updated_by' => $actorId, 'updated_at' => $now, 'created_by' => $actorId, 'created_at' => $now],
                );
            }

            $this->ensureCashAndBankDefaults($tenantId, $actorId);
            $this->ensureSettlementMethodDefaults($tenantId, $actorId);
            $branchIds = DB::table('branches')->where('tenant_id', $tenantId)
                ->where('is_active', true)->whereNull('deleted_at')->pluck('id');
            foreach ($branchIds as $branchId) {
                $this->ensureBranchCashDrawer($tenantId, (int) $branchId, $actorId);
                $this->ensureDefaultShiftCloseDestination($tenantId, (int) $branchId);
            }
            $this->ensureSalesDefaults($tenantId, $actorId);
            $this->ensureDefaultInvoiceTypes($tenantId);

            if ($initialBranchId) {
                $this->ensureBranchWarehouse($tenantId, $initialBranchId, $warehouseName, $actorId);
            }
        });
    }

    /** Establishes only tenant configuration and the single protected cash customer; it does not post anything. */
    private function ensureSalesDefaults(int $tenantId, ?int $actorId): void
    {
        $now = now();
        $account = DB::table('financial_accounts')->where('tenant_id', $tenantId)->where('code', '1200')->first();
        if (! $account || $account->account_group !== 'assets' || $account->normal_balance !== 'debit') {
            throw new \RuntimeException("Tenant {$tenantId} requires account 1200 as an asset account with debit normal balance.");
        }
        // A tenant may later deliberately remap AR through finance settings;
        // setup establishes the safe default but must never overwrite that choice.
        if (! DB::table('sales_account_mappings')->where('tenant_id', $tenantId)->where('mapping_key', 'sales.accounts_receivable')->exists()) {
            DB::table('sales_account_mappings')->insert([
                'tenant_id' => $tenantId, 'mapping_key' => 'sales.accounts_receivable', 'financial_account_id' => $account->id,
                'created_at' => $now, 'updated_at' => $now,
            ]);
        }
        foreach (['sales.revenue' => '4000', 'sales.tax_payable' => '2010', 'sales.cost_of_goods_sold' => '5000', 'sales.inventory_asset' => '1100', 'sales.sales_returns' => '4020', 'sales.customer_credit' => '2020', 'sales.additional_charge_revenue' => '4030', 'sales.manual_adjustment' => '4030',
            'sales.discount_given' => '4010', 'inventory.variance' => '5010', 'inventory.opening_equity' => '3000', 'cash.over' => '4040', 'cash.short' => '6180', 'cash.drawer' => '1010'] as $key => $code) {
            if (DB::table('sales_account_mappings')->where('tenant_id', $tenantId)->where('mapping_key', $key)->exists()) {
                continue;
            }
            $accountId = DB::table('financial_accounts')->where('tenant_id', $tenantId)->where('code', $code)->value('id');
            if ($accountId) {
                DB::table('sales_account_mappings')->insert(['tenant_id' => $tenantId, 'mapping_key' => $key, 'financial_account_id' => $accountId, 'created_at' => $now, 'updated_at' => $now]);
            }
        }

        $walkIn = DB::table('customers')->where('tenant_id', $tenantId)->where('is_walk_in', true)->first();
        if (! $walkIn) {
            $name = CustomerNameNormalizer::normalize('Cash / Walk-in Customer');
            DB::table('customers')->insert([
                'tenant_id' => $tenantId, 'customer_number' => 'CASH-CUSTOMER', 'name' => 'Cash / Walk-in Customer',
                'normalized_name' => $name['normalizedName'],
                'customer_type' => 'walk_in', 'default_credit_terms_days' => 0, 'total_spent' => 0, 'visits_count' => 0,
                'is_active' => true, 'is_walk_in' => true, 'is_system_protected' => true, 'created_by' => $actorId,
                'updated_by' => $actorId, 'created_at' => $now, 'updated_at' => $now,
            ]);

            return;
        }
        DB::table('customers')->where('id', $walkIn->id)->update([
            'is_active' => true, 'is_system_protected' => true, 'updated_by' => $actorId, 'updated_at' => $now,
        ]);
    }

    /**
     * Pre-existing gap fixed here: `invoice_groups`/`invoice_types` were
     * only ever backfilled once, by the migration that introduced them, for
     * tenants that already existed at that moment (see
     * 2026_09_10_000019_create_invoice_type_catalog). No seeder or service
     * carried that forward for tenants provisioned afterwards, so every
     * supplier invoice attempt for a new tenant failed
     * ("Select an active configured invoice type.") — this is what
     * SupplierInvoiceService::withResolvedType() requires to exist. This
     * mirrors the migration's own seed data exactly (same codes, names, and
     * posting behaviors) via the same idempotent updateOrInsert pattern used
     * everywhere else in this method.
     */
    private function ensureDefaultInvoiceTypes(int $tenantId): void
    {
        $now = now();
        DB::table('invoice_groups')->updateOrInsert(
            ['tenant_id' => $tenantId, 'code' => 'accounting'],
            ['name' => 'فواتير محاسبية', 'description' => 'فواتير يمكن ترحيلها إلى القيود المحاسبية.', 'is_active' => true, 'updated_at' => $now, 'created_at' => $now],
        );
        DB::table('invoice_groups')->updateOrInsert(
            ['tenant_id' => $tenantId, 'code' => 'test'],
            ['name' => 'فواتير تجريبية', 'description' => 'للتجارب والتوثيق فقط؛ لا تنشئ قيوداً محاسبية.', 'is_active' => true, 'updated_at' => $now, 'created_at' => $now],
        );
        $accountingGroupId = (int) DB::table('invoice_groups')->where('tenant_id', $tenantId)->where('code', 'accounting')->value('id');
        $testGroupId = (int) DB::table('invoice_groups')->where('tenant_id', $tenantId)->where('code', 'test')->value('id');

        foreach ([
            ['code' => 'expense', 'name' => 'مصروف', 'posting_behavior' => 'expense', 'is_postable' => true, 'is_purchase' => true, 'group' => $accountingGroupId],
            ['code' => 'inventory', 'name' => 'مخزون', 'posting_behavior' => 'inventory', 'is_postable' => true, 'is_purchase' => true, 'group' => $accountingGroupId],
            ['code' => 'other', 'name' => 'أخرى', 'posting_behavior' => 'other', 'is_postable' => true, 'is_purchase' => true, 'group' => $accountingGroupId],
            ['code' => 'test', 'name' => 'فاتورة تجريبية', 'posting_behavior' => 'none', 'is_postable' => false, 'is_purchase' => false, 'group' => $testGroupId],
        ] as $type) {
            DB::table('invoice_types')->updateOrInsert(
                ['tenant_id' => $tenantId, 'code' => $type['code']],
                ['invoice_group_id' => $type['group'], 'name' => $type['name'], 'posting_behavior' => $type['posting_behavior'], 'is_postable' => $type['is_postable'], 'is_purchase' => $type['is_purchase'], 'is_active' => true, 'updated_at' => $now, 'created_at' => $now],
            );
        }
    }

    /** Creates configuration only; balances remain entirely journal-derived. */
    private function ensureCashAndBankDefaults(int $tenantId, ?int $actorId): void
    {
        $now = now();
        $accounts = DB::table('financial_accounts')->where('tenant_id', $tenantId)->whereIn('code', ['1010', '1020', '1030'])->pluck('id', 'code');
        foreach ([
            ['code' => 'CASH-DRAWER', 'name' => 'صندوق نقطة البيع', 'kind' => 'cash', 'type' => 'cash_drawer', 'accountCode' => '1010'],
            ['code' => 'MAIN-SAFE', 'name' => 'الخزنة الرئيسية', 'kind' => 'cash', 'type' => 'main_safe', 'accountCode' => '1020'],
            ['code' => 'BANK', 'name' => 'البنك', 'kind' => 'bank', 'type' => 'bank', 'accountCode' => '1030'],
        ] as $location) {
            $accountId = $accounts[$location['accountCode']] ?? null;
            if (! $accountId) {
                continue;
            }
            if ($location['code'] === 'CASH-DRAWER' && DB::table('financial_locations')->where('tenant_id', $tenantId)->where('code', 'CASH-DRAWER')->exists()) {
                continue;
            }
            $existingName = DB::table('financial_locations')->where('tenant_id', $tenantId)->where('code', $location['code'])->value('name');
            if ($existingName !== null) $location['name'] = $existingName;
            DB::table('financial_locations')->updateOrInsert(['tenant_id' => $tenantId, 'code' => $location['code']], ['branch_id' => null, 'financial_account_id' => $accountId, 'name' => $location['name'], 'kind' => $location['kind'], 'type' => $location['type'], 'bank_name' => null, 'masked_reference' => null, 'is_active' => true, 'updated_by' => $actorId, 'updated_at' => $now, 'created_by' => $actorId, 'created_at' => $now]);
        }
        if (isset($accounts['1010'])) {
            $existingName = DB::table('payment_methods')->where('tenant_id', $tenantId)->where('code', 'CASH')->value('name');
            DB::table('payment_methods')->updateOrInsert(['tenant_id' => $tenantId, 'code' => 'CASH'], ['name' => $existingName ?? 'نقدي', 'type' => 'cash', 'financial_account_id' => $accounts['1010'], 'financial_location_id' => null, 'is_active' => true, 'sort_order' => 1, 'updated_by' => $actorId, 'updated_at' => $now, 'created_by' => $actorId, 'created_at' => $now]);
        }
    }

    /**
     * Sham Cash (an electronic wallet with its own "box") and the customer wallet. Sham Cash money is
     * held in its own asset account + location, so its statement/reconciliation is separate from the
     * drawer and the bank. The WALLET method has no ledger account of its own: a wallet payment is
     * posted on the paying customer's single party account (the mapped account here is only the
     * receivables control account used when a configuration needs a placeholder).
     * Idempotent and name-preserving: an existing row keeps whatever name the owner gave it.
     */
    public function ensureSettlementMethodDefaults(int $tenantId, ?int $actorId = null): void
    {
        $now = now();
        $shamAccountId = DB::table('financial_accounts')->where('tenant_id', $tenantId)->where('code', '1040')->value('id');
        $shamLocationId = null;
        if ($shamAccountId) {
            $existing = DB::table('financial_locations')->where('tenant_id', $tenantId)->where('code', 'SHAM-CASH')->first(['id', 'name']);
            $taken = DB::table('financial_locations')->where('tenant_id', $tenantId)->where('financial_account_id', $shamAccountId)->where('code', '<>', 'SHAM-CASH')->exists();
            if (! $taken) {
                DB::table('financial_locations')->updateOrInsert(['tenant_id' => $tenantId, 'code' => 'SHAM-CASH'], ['branch_id' => null, 'financial_account_id' => $shamAccountId, 'name' => $existing->name ?? 'صندوق الشام كاش', 'kind' => 'bank', 'type' => 'bank', 'bank_name' => 'الشام كاش', 'masked_reference' => null, 'is_active' => true, 'updated_by' => $actorId, 'updated_at' => $now, 'created_by' => $actorId, 'created_at' => $now]);
                $shamLocationId = DB::table('financial_locations')->where('tenant_id', $tenantId)->where('code', 'SHAM-CASH')->value('id');
            }
            if ($shamLocationId) {
                $name = DB::table('payment_methods')->where('tenant_id', $tenantId)->where('code', 'SHAM-CASH')->value('name');
                DB::table('payment_methods')->updateOrInsert(['tenant_id' => $tenantId, 'code' => 'SHAM-CASH'], ['name' => $name ?? 'شام كاش', 'type' => 'sham_cash', 'financial_account_id' => $shamAccountId, 'financial_location_id' => $shamLocationId, 'is_active' => true, 'sort_order' => 3, 'updated_by' => $actorId, 'updated_at' => $now, 'created_by' => $actorId, 'created_at' => $now]);
            }
        }
        $receivableId = DB::table('financial_accounts')->where('tenant_id', $tenantId)->whereIn('code', ['1200', '121'])->where('is_active', true)->orderByRaw("CASE WHEN code = '1200' THEN 0 ELSE 1 END")->value('id');
        if ($receivableId) {
            $name = DB::table('payment_methods')->where('tenant_id', $tenantId)->where('code', 'WALLET')->value('name');
            DB::table('payment_methods')->updateOrInsert(['tenant_id' => $tenantId, 'code' => 'WALLET'], ['name' => $name ?? 'محفظة العميل', 'type' => 'wallet', 'financial_account_id' => $receivableId, 'financial_location_id' => null, 'is_active' => true, 'sort_order' => 4, 'updated_by' => $actorId, 'updated_at' => $now, 'created_by' => $actorId, 'created_at' => $now]);
        }
    }

    /**
     * Provisioning default only: a branch with NO shift close destination gets
     * the tenant's protected global MAIN-SAFE, so a freshly provisioned branch
     * can run a closable shift. An explicit destination is never replaced, and
     * already-open shifts are never touched (they keep their snapshot).
     */
    public function ensureDefaultShiftCloseDestination(int $tenantId, int $branchId): ?int
    {
        if (! Schema::hasColumn('branches', 'shift_close_destination_financial_location_id')) {
            return null;
        }
        $branch = DB::table('branches')->where('tenant_id', $tenantId)->where('id', $branchId)->first();
        if (! $branch || $branch->shift_close_destination_financial_location_id) {
            return $branch?->shift_close_destination_financial_location_id ? (int) $branch->shift_close_destination_financial_location_id : null;
        }
        $safe = DB::table('financial_locations as l')->join('financial_accounts as a', 'a.id', '=', 'l.financial_account_id')
            ->where('l.tenant_id', $tenantId)->where('l.code', 'MAIN-SAFE')->whereNull('l.branch_id')
            ->where('l.kind', 'cash')->where('l.is_active', true)
            ->where('a.tenant_id', $tenantId)->where('a.is_active', true)->whereNull('a.deleted_at')
            ->value('l.id');
        if (! $safe || (int) $safe === (int) $branch->pos_cash_financial_location_id) {
            return null;
        }
        DB::table('branches')->where('id', $branchId)->whereNull('shift_close_destination_financial_location_id')
            ->update(['shift_close_destination_financial_location_id' => $safe, 'updated_at' => now()]);

        return (int) $safe;
    }

    /** Keep an existing branch drawer's ID and account; never substitute the global legacy drawer. */
    public function ensureBranchCashDrawer(int $tenantId, int $branchId, ?int $actorId = null): int
    {
        return DB::transaction(function () use ($tenantId, $branchId, $actorId): int {
            $branch = DB::table('branches')->where('tenant_id', $tenantId)->where('id', $branchId)
                ->where('is_active', true)->whereNull('deleted_at')->lockForUpdate()->first();
            if (! $branch) {
                throw new \RuntimeException("Active branch {$branchId} is unavailable for tenant {$tenantId}.");
            }
            $hasConfiguredColumn = Schema::hasColumn('branches', 'pos_cash_financial_location_id');
            $drawers = DB::table('financial_locations')->where('tenant_id', $tenantId)->where('branch_id', $branchId)
                ->where('kind', 'cash')->where('type', 'cash_drawer')->get();
            $active = $drawers->where('is_active', true);
            if ($hasConfiguredColumn && $branch->pos_cash_financial_location_id) {
                $configured = $active->firstWhere('id', (int) $branch->pos_cash_financial_location_id);
                if (! $configured || ! DB::table('financial_accounts')->where('tenant_id', $tenantId)
                    ->where('id', $configured->financial_account_id)->where('is_active', true)->whereNull('deleted_at')->exists()) {
                    throw new \RuntimeException("Branch {$branchId} has an invalid configured POS cash drawer.");
                }
                return (int) $configured->id;
            }
            if ($active->count() > 1) {
                throw new \RuntimeException("Branch {$branchId} has multiple active cash drawers and no configured POS drawer.");
            }
            if ($active->count() === 1) {
                $id = (int) $active->first()->id;
                if (! DB::table('financial_accounts')->where('tenant_id', $tenantId)
                    ->where('id', $active->first()->financial_account_id)->where('is_active', true)->whereNull('deleted_at')->exists()) {
                    throw new \RuntimeException("Branch {$branchId} cash drawer has an inactive account.");
                }
                if ($hasConfiguredColumn && ! $branch->pos_cash_financial_location_id) {
                    DB::table('branches')->where('id', $branchId)->update(['pos_cash_financial_location_id' => $id, 'updated_at' => now()]);
                }
                return $id;
            }
            if ($drawers->count() > 1) {
                throw new \RuntimeException("Branch {$branchId} has ambiguous inactive cash drawers.");
            }
            if ($drawers->count() === 1) {
                $id = (int) $drawers->first()->id;
                DB::table('financial_locations')->where('id', $id)->update(['is_active' => true, 'updated_by' => $actorId, 'updated_at' => now()]);
                if ($hasConfiguredColumn) DB::table('branches')->where('id', $branchId)->update(['pos_cash_financial_location_id' => $id, 'updated_at' => now()]);
                return $id;
            }
            $accountId = app(FinanceAccountMap::class)->account($tenantId, 'cash.drawer')->id ?? null;
            if (! $accountId) {
                throw new \RuntimeException("Tenant {$tenantId} has no active cash drawer account mapped (cash.drawer).");
            }
            $id = (int) DB::table('financial_locations')->insertGetId([
                'tenant_id' => $tenantId, 'branch_id' => $branchId, 'financial_account_id' => $accountId,
                'code' => 'CASH-DRAWER-BR-'.$branchId, 'name' => 'صندوق '.$branch->name,
                'kind' => 'cash', 'type' => 'cash_drawer', 'bank_name' => null, 'masked_reference' => null,
                'is_active' => true, 'created_by' => $actorId, 'updated_by' => $actorId,
                'created_at' => now(), 'updated_at' => now(),
            ]);
            if ($hasConfiguredColumn) DB::table('branches')->where('id', $branchId)->update(['pos_cash_financial_location_id' => $id, 'updated_at' => now()]);
            return $id;
        });
    }

    /**
     * There is no "main"/"primary" warehouse concept: a branch cannot
     * operate without at least one place to hold stock, so exactly one
     * warehouse is created at branch-creation time, named by whoever
     * created the branch (defaults to "البار", the common case). If the
     * branch already has a warehouse (added manually, or this ran before),
     * nothing is created — this never produces a second, competing store.
     */
    public function ensureBranchWarehouse(int $tenantId, int $branchId, ?string $name = null, ?int $actorId = null): void
    {
        $branch = DB::table('branches')->where('tenant_id', $tenantId)->where('id', $branchId)->whereNull('deleted_at')->first();
        if (! $branch) {
            return;
        }
        if (($branch->branch_type ?? 'cafe') === 'factory') {
            app(FactoryCatalogService::class)->ensureForBranch($tenantId, $branchId);
        }
        if ($branch->is_active) {
            $this->ensureBranchCashDrawer($tenantId, $branchId, $actorId);
        }
        if (DB::table('warehouses')->where('tenant_id', $tenantId)->where('branch_id', $branchId)->whereNull('deleted_at')->exists()) {
            if (($branch->branch_type ?? 'cafe') === 'factory' && ! $branch->default_warehouse_id) {
                $existingId = DB::table('warehouses')->where('tenant_id', $tenantId)->where('branch_id', $branchId)->where('is_active', true)->whereNull('deleted_at')->orderBy('id')->value('id');
                if ($existingId) DB::table('branches')->where('id', $branchId)->update(['default_warehouse_id' => $existingId, 'pos_inventory_warehouse_id' => null, 'updated_at' => now()]);
            }
            return;
        }

        $now = now();
        $isFactory = ($branch->branch_type ?? 'cafe') === 'factory';
        $warehouseName = $name !== null && trim($name) !== '' ? trim($name) : $branch->name.($isFactory ? ' — المخزن' : ' — البار');
        $warehouseId = DB::table('warehouses')->insertGetId([
            'tenant_id' => $tenantId,
            'branch_id' => $branchId,
            'name' => $warehouseName,
            'code' => 'BR-'.$branchId.'-1',
            'type' => $isFactory ? 'factory' : 'bar',
            'is_active' => true,
            'notes' => null,
            'updated_by' => $actorId,
            'updated_at' => $now,
            'created_by' => $actorId,
            'created_at' => $now,
        ]);
        DB::table('branches')->where('tenant_id', $tenantId)->where('id', $branchId)->update([
            'default_warehouse_id' => $warehouseId,
            'pos_inventory_warehouse_id' => $isFactory ? null : $warehouseId,
            'updated_at' => $now,
        ]);
    }
}
