<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\CustomerManagementService;
use App\Services\OperationalAuditService;
use App\Support\Search\SmartSearch;
use App\Support\FinanceAccess;
use App\Support\FinancialActor;
use App\Support\TenantContext;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class FinanceCustomerController extends Controller
{
    public function __construct(private readonly CustomerManagementService $customers, private readonly OperationalAuditService $audit) {}

    public function index(Request $request): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $query = DB::table('customers')->where('tenant_id', $tenant)->whereNull('deleted_at');
\App\Support\DataScope::apply($query, 'owner_branch_id', \App\Support\DataScope::resolve($request));
        if ($request->filled('status')) $query->where('is_active', $request->input('status') === 'active');
        $search = $request->input('search');
        $searchFields = [
            ['column' => 'name', 'weight' => 3],
            ['column' => 'phone', 'weight' => 2, 'type' => 'phone'],
            ['column' => 'customer_number', 'weight' => 2, 'type' => 'code'],
            ['column' => 'email', 'weight' => 1],
        ];
        if ($request->filled('search')) {
            SmartSearch::apply($query, $search, $searchFields);
            SmartSearch::withRelevance($query, $search, $searchFields);
            $query->orderByDesc('smart_rank');
        }
        $paginator = $query->orderBy('name')->paginate($this->perPage($request));
        $permissions = array_fill_keys(FinanceAccess::capabilities($request), true);
        return response()->json(['data' => collect($paginator->items())->map(fn (object $customer) => $this->serialize($customer) + ['allowedActions' => $this->actions($permissions)])->values(), 'meta' => $this->meta($paginator)]);
    }

    public function store(Request $request): JsonResponse
    {
        $tenant = TenantContext::id($request); $actor = FinancialActor::id($request, $tenant);
        $customer = $this->customers->create($tenant, $actor, $this->data($request, true), $request);
        $this->audit->record($request, $tenant, 'sales.customer.created', 'customer', $customer->id, [], ['name' => $customer->name], null, $actor);
        return response()->json(['data' => $this->serialize($customer) + ['allowedActions' => $this->actions(array_fill_keys(FinanceAccess::capabilities($request), true))]], 201);
    }

    public function show(Request $request, int $customer): JsonResponse { return response()->json(['data' => $this->serialize(\App\Support\DataScope::find($request, TenantContext::id($request), 'customers', $customer)) + ['allowedActions' => $this->actions(array_fill_keys(FinanceAccess::capabilities($request), true))]]); }

    public function update(Request $request, int $customer): JsonResponse
    {
        $tenant = TenantContext::id($request); $actor = FinancialActor::id($request, $tenant); $before = \App\Support\DataScope::find($request, $tenant, 'customers', $customer);
        $limit = $request->validate(['walletCreditLimit' => ['sometimes', 'nullable', 'regex:/^\d+(\.\d{1,2})?$/']]);
        if (array_key_exists('walletCreditLimit', $limit)) {
            // Only the owner decides how far a customer's wallet may go below zero.
            abort_unless(DB::table('users')->where('tenant_id', $tenant)->where('id', $actor)->where('role', 'owner')->whereNull('deleted_at')->exists(), 403, 'Owner access required.');
            DB::table('customers')->where('tenant_id', $tenant)->where('id', $customer)->update(['wallet_credit_limit' => $limit['walletCreditLimit'] ?? '0', 'updated_at' => now()]);
            $this->audit->record($request, $tenant, 'sales.customer.wallet_limit_changed', 'customer', $customer, ['limit' => $before->wallet_credit_limit ?? '0'], ['limit' => $limit['walletCreditLimit'] ?? '0'], null, $actor);
        }
        $after = $this->customers->update($tenant, $customer, $actor, $this->data($request, false));
        $after = \App\Support\DataScope::find($request, $tenant, 'customers', $customer);
        $this->audit->record($request, $tenant, 'sales.customer.updated', 'customer', $customer, ['name' => $before->name, 'isActive' => (bool) $before->is_active], ['name' => $after->name, 'isActive' => (bool) $after->is_active], null, $actor);
        return response()->json(['data' => $this->serialize($after) + ['allowedActions' => $this->actions(array_fill_keys(FinanceAccess::capabilities($request), true))]]);
    }

    private function data(Request $request, bool $creating): array
    {
        return $request->validate([
            'isInternal' => ['sometimes', 'boolean'], 'internalBranchId' => ['nullable', 'integer'],
            'name' => [$creating ? 'required' : 'sometimes', 'string', 'max:255'], 'phone' => ['nullable', 'string', 'max:40'], 'email' => ['nullable', 'email', 'max:255'],
            'taxNumber' => ['nullable', 'string', 'max:128'], 'defaultCreditTermsDays' => ['nullable', 'integer', 'min:0', 'max:365'], 'notes' => ['nullable', 'string', 'max:5000'], 'isActive' => ['sometimes', 'boolean'],
        ]);
    }
    private function serialize(object $c): array { return ['id' => (int) $c->id, 'financialAccountId' => $c->financial_account_id ? (int) $c->financial_account_id : null, 'customerNumber' => $c->customer_number, 'isInternal' => (bool) $c->is_internal, 'internalBranchId' => $c->internal_branch_id ? (int) $c->internal_branch_id : null, 'name' => $c->name, 'customerType' => $c->customer_type, 'phone' => $c->phone, 'email' => $c->email, 'taxNumber' => $c->tax_number, 'defaultCreditTermsDays' => (int) $c->default_credit_terms_days, 'notes' => $c->notes, 'isActive' => (bool) $c->is_active, 'isWalkIn' => (bool) $c->is_walk_in, 'isSystemProtected' => (bool) $c->is_system_protected] + $this->wallet($c); }
    /** Wallet card data: funds held for the customer and the owner-set credit limit. */
    private function wallet(object $c): array
    {
        $state = app(\App\Services\PartyAccountService::class)->walletState((int) $c->tenant_id, (int) $c->id);

        return ['walletBalance' => \App\Support\Money::decimal($state['fundsCents']), 'walletCreditLimit' => \App\Support\Money::decimal($state['limitCents']), 'walletAvailable' => \App\Support\Money::decimal($state['availableCents'])];
    }

    private function actions(array $p): array { return array_values(array_filter(['edit' => isset($p['finance.customers.edit']) ? 'edit' : null])); }
    private function perPage(Request $request): int { return min(max((int) $request->query('perPage', 50), 1), 100); }
    private function meta($p): array { return ['currentPage' => $p->currentPage(), 'perPage' => $p->perPage(), 'total' => $p->total(), 'lastPage' => $p->lastPage()]; }
}
