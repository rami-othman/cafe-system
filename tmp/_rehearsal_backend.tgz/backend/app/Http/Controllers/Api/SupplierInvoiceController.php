<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\SupplierInvoiceService;
use App\Services\SupplierPayableQueryService;
use App\Support\FinanceAccess;
use App\Support\FinancialActor;
use App\Support\Money;
use App\Support\TenantContext;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SupplierInvoiceController extends Controller
{
    public function __construct(private readonly SupplierInvoiceService $invoices, private readonly SupplierPayableQueryService $payable, private readonly \App\Services\PurchasePostingOrchestrator $purchasePosting) {}

    public function index(Request $request): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $actor = FinancialActor::id($request, $tenant);
        $q = $this->rows($tenant);
        if (DB::table('users')->where('tenant_id', $tenant)->where('id', $actor)->value('role') !== 'owner') {
            \App\Support\BranchScope::applyFinancial($q, 'i.branch_id', FinancialActor::user($actor, $tenant));
        }
        foreach (['supplierId' => 'i.supplier_id', 'branchId' => 'i.branch_id', 'status' => 'i.status', 'invoiceType' => 'i.invoice_type'] as $input => $column) {
            if ($request->filled($input)) {
                $q->where($column, $request->input($input));
            }
        }
        if ($request->boolean('overdueOnly')) {
            $q->whereIn('i.status', ['posted', 'partially_paid'])->where('i.due_date', '<', now()->toDateString());
        }
        if ($request->filled('from')) {
            $q->whereDate('i.invoice_date', '>=', $request->input('from'));
        }
        if ($request->filled('to')) {
            $q->whereDate('i.invoice_date', '<=', $request->input('to'));
        }

        $permissions = array_fill_keys(FinanceAccess::capabilities($request), true);
        $paginator = $q->orderByDesc('i.invoice_date')->orderByDesc('i.id')->paginate($this->perPage($request));

        return response()->json(['data' => collect($paginator->items())->map(fn (object $row) => $this->serialize($row) + ['allowedActions' => $this->actions($row, $permissions)])->values(), 'meta' => $this->meta($paginator)]);
    }

    public function show(Request $request, int $invoice): JsonResponse
    {
        $tenant = TenantContext::id($request);

        return response()->json(['data' => $this->one($tenant, $invoice, $request)]);
    }

    private function perPage(Request $request): int
    {
        return min(max((int) $request->query('perPage', 100), 1), 100);
    }

    private function meta($paginator): array
    {
        return ['currentPage' => $paginator->currentPage(), 'perPage' => $paginator->perPage(), 'total' => $paginator->total(), 'lastPage' => $paginator->lastPage()];
    }

    public function store(Request $request): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $id = $this->invoices->create($request, $tenant, $this->draftData($request), FinancialActor::id($request, $tenant))->id;

        return response()->json(['data' => $this->one($tenant, $id, $request)], 201);
    }

    public function update(Request $request, int $invoice): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $this->invoices->update($request, $tenant, $invoice, $this->draftData($request), FinancialActor::id($request, $tenant));

        return response()->json(['data' => $this->one($tenant, $invoice, $request)]);
    }

    public function post(Request $request, int $invoice): JsonResponse
    {
        $data = $request->validate(['idempotencyKey' => ['required', 'string', 'max:120']]);
        $tenant = TenantContext::id($request);
        $before = $this->invoices->find($tenant, $invoice);
        if ($before->receipt_mode === 'immediate') {
            $this->purchasePosting->post($request, $tenant, $invoice, $data['idempotencyKey'], FinancialActor::id($request, $tenant), paidAmount: '0.00');
        } else {
            $this->invoices->post($request, $tenant, $invoice, $data, FinancialActor::id($request, $tenant));
        }
        $warning = \App\Support\BackdatePolicy::closedDayWarning($tenant, $before->branch_id ? (int) $before->branch_id : null, $before->invoice_date);

        return response()->json(['data' => $this->one($tenant, $invoice, $request), 'warnings' => $warning ? [$warning] : []]);
    }

    public function reverse(Request $request, int $invoice): JsonResponse
    {
        $tenant = TenantContext::id($request);
        $this->invoices->reverse($request, $tenant, $invoice, FinancialActor::id($request, $tenant));

        return response()->json(['data' => $this->one($tenant, $invoice, $request)]);
    }

    private function draftData(Request $request): array
    {
        return $request->validate([
            ...\App\Support\FactoryCurrency::rules(),
            'branchId' => ['nullable', 'integer'],
            'receiptMode' => ['nullable', 'in:immediate,receive_later'],
            'supplierId' => ['required', 'integer'],
            'invoiceNumber' => ['nullable', 'string', 'max:80'],
            'supplierInvoiceNumber' => ['nullable', 'string', 'max:80'],
            'invoiceDate' => ['required', 'date'],
            // The due date only has meaning for a credit (آجل) invoice; cash / Sham Cash invoices are due on their date.
            'paymentTerms' => ['nullable', 'in:cash,credit,sham_cash'],
            'paymentReference' => ['nullable', 'string', 'max:120'],
            'dueDate' => ['required_unless:paymentTerms,cash,sham_cash', 'nullable', 'date'],
            // invoiceType remains accepted for older clients; new clients select a configured type.
            'invoiceTypeId' => ['nullable', 'integer', 'required_without:invoiceType'],
            'invoiceType' => ['nullable', 'in:expense,inventory,other'],
            'expenseCategoryId' => ['nullable', 'integer'],
            'debitAccountId' => ['nullable', 'integer'],
            // Required only for the legacy header-only path — when `lines` is
            // present the server derives subtotal/taxAmount from the lines
            // and ignores these two (see SupplierInvoiceService::buildLines).
            'subtotal' => ['required_without:lines', 'regex:/^\d+(\.\d{1,2})?$/'],
            'taxAmount' => ['nullable', 'regex:/^\d+(\.\d{1,2})?$/'],
            'description' => ['nullable', 'string', 'max:1000'],
            'notes' => ['nullable', 'string', 'max:5000'],
            'idempotencyKey' => ['nullable', 'string', 'max:120'],
            'backdateReason' => ['nullable', 'string', 'max:1000'],
            // Whole-invoice discount — allocated proportionally into the lines' cost
            // basis (and their commercial total) when lines are present; see
            // SupplierInvoiceService::invoiceDiscount()/allocateAndFinalize().
            'discountType' => ['nullable', 'in:fixed,percentage'],
            'discountValue' => ['nullable', 'regex:/^\d+(\.\d{1,2})?$/'],
            'lines' => ['nullable', 'array', 'min:1'],
            'lines.*.lineType' => ['required_with:lines', 'in:inventory,expense,asset,other'],
            'lines.*.description' => ['required_with:lines', 'string', 'max:500'],
            'lines.*.inventoryItemId' => ['nullable', 'integer'],
            'lines.*.purchaseUnit' => ['nullable', 'string', 'max:40'],
            'lines.*.quantity' => ['nullable', 'regex:/^\d+(\.\d{1,3})?$/'],
            // The client sends the line's gross purchase total, never a unit price — the
            // server derives unit cost from (gross - discount) / quantity (see buildLines()).
            'lines.*.unitCost' => ['nullable', 'regex:/^\d+(\.\d{1,4})?$/'],
            'lines.*.lineGrossAmount' => ['nullable', 'regex:/^\d+(\.\d{1,2})?$/'],
            'lines.*.discountType' => ['nullable', 'in:fixed,percentage'],
            'lines.*.discountValue' => ['nullable', 'regex:/^\d+(\.\d{1,2})?$/'],
            'lines.*.taxAmount' => ['nullable', 'regex:/^\d+(\.\d{1,2})?$/'],
            'lines.*.warehouseId' => ['nullable', 'integer'],
            // Additional charges (freight, hospitality, ...) — only meaningful
            // alongside `lines`; see SupplierInvoiceService::buildCharges().
            'charges' => ['nullable', 'array'],
            'charges.*.description' => ['required_with:charges', 'string', 'max:255'],
            'charges.*.treatment' => ['required_with:charges', 'in:capitalize,expense'],
            'charges.*.expenseCategoryId' => ['nullable', 'integer', 'required_if:charges.*.treatment,expense'],
            'charges.*.amount' => ['required_with:charges', 'regex:/^\d+(\.\d{1,2})?$/'],
            'charges.*.taxAmount' => ['nullable', 'regex:/^\d+(\.\d{1,2})?$/'],
        ]);
    }

    private function rows(int $tenant)
    {
        return DB::table('supplier_invoices as i')
            ->join('suppliers as s', 's.id', '=', 'i.supplier_id')
            ->join('financial_accounts as a', 'a.id', '=', 'i.debit_account_id')
            ->leftJoin('branches as b', 'b.id', '=', 'i.branch_id')
            ->leftJoin('expense_categories as c', 'c.id', '=', 'i.expense_category_id')
            ->leftJoin('invoice_types as t', 't.id', '=', 'i.invoice_type_id')
            ->leftJoin('invoice_groups as g', 'g.id', '=', 't.invoice_group_id')
            ->where('i.tenant_id', $tenant)->whereNull('i.deleted_at')
            ->select('i.*', 's.name as supplier_name', 's.supplier_number', 'a.code as debit_account_code', 'a.name_ar as debit_account_name', 'b.name as branch_name', 'c.name as expense_category_name', 't.name as configured_type_name', 't.posting_behavior as configured_posting_behavior', 't.is_postable as configured_is_postable', 'g.name as invoice_group_name');
    }

    private function one(int $tenant, int $id, Request $request): array
    {
        $row = $this->rows($tenant)->where('i.id', $id)->first();
        abort_unless($row, 404);
        $actor = FinancialActor::id($request, $tenant);
        FinancialActor::assertBranchAccess($actor, $tenant, $row->branch_id ? (int) $row->branch_id : null);

        return $this->serialize($row)
            + ['lines' => $this->serializeLines($this->invoices->lines($tenant, $id))]
            + ['charges' => $this->serializeCharges($this->invoices->charges($tenant, $id))]
            + ['allowedActions' => $this->actions($row, array_fill_keys(FinanceAccess::capabilities($request), true))];
    }

    /** @param array<int, object> $lines */
    private function serializeLines(array $lines): array
    {
        return array_map(fn (object $l): array => [
            'id' => (int) $l->id,
            'lineNumber' => (int) $l->line_number,
            'lineType' => $l->line_type,
            'description' => $l->description,
            'inventoryItemId' => $l->inventory_item_id ? (int) $l->inventory_item_id : null,
            'inventoryItemName' => $l->inventory_item_name,
            'purchaseUnit' => $l->purchase_unit,
            'baseUnit' => $l->inventory_item_base_unit,
            'quantity' => $l->quantity,
            'conversionFactor' => $l->conversion_factor,
            'baseQuantity' => $l->base_quantity,
            'unitPrice' => $l->unit_price,
            'lineGrossAmount' => $l->line_gross_amount,
            'discountType' => $l->discount_type,
            'discountValue' => $l->discount_value,
            'discountAmount' => $l->discount_amount,
            'allocatedDiscount' => $l->allocated_discount,
            'allocatedLandedCost' => $l->allocated_landed_cost,
            'taxAmount' => $l->tax_amount,
            'lineTotal' => $l->line_total,
            'warehouseId' => $l->warehouse_id ? (int) $l->warehouse_id : null,
            'receivedQuantity' => $l->received_quantity,
        ], $lines);
    }

    /** @param array<int, object> $charges */
    private function serializeCharges(array $charges): array
    {
        return array_map(fn (object $c): array => [
            'id' => (int) $c->id,
            'chargeNumber' => (int) $c->charge_number,
            'description' => $c->description,
            'treatment' => $c->treatment,
            'expenseCategoryId' => $c->expense_category_id ? (int) $c->expense_category_id : null,
            'expenseCategoryName' => $c->expense_category_name,
            'amount' => $c->amount,
            'taxAmount' => $c->tax_amount,
        ], $charges);
    }

    private function actions(object $row, array $permissions): array
    {
        $can = fn (string $permission): bool => isset($permissions[$permission]);
        $actions = [];
        if ($row->status === 'draft' && $can('finance.supplier_invoices.edit')) {
            $actions[] = 'edit';
        }
        if ($row->status === 'draft' && $row->configured_is_postable && $can('finance.supplier_invoices.post')) {
            $actions[] = 'post';
        }
        if (in_array($row->status, ['posted', 'partially_paid'], true) && $can('finance.supplier_invoices.reverse')) {
            $actions[] = 'reverse';
        }

        return $actions;
    }

    private function serialize(object $row): array
    {
        $remaining = $this->payable->invoiceRemainingCents((int) $row->tenant_id, (int) $row->id);
        $isOverdue = in_array($row->status, ['posted', 'partially_paid'], true) && $remaining > 0 && $row->due_date < now()->toDateString();

        return [
            'id' => (int) $row->id,
            'internalReference' => $row->internal_reference,
            'invoiceNumber' => $row->internal_reference,
            'supplierInvoiceNumber' => $row->invoice_number,
            'supplierInternalReference' => $row->supplier_internal_reference,
            'externalSupplierReference' => $row->invoice_number,
            'supplierId' => (int) $row->supplier_id,
            'supplierName' => $row->supplier_name,
            'supplierNumber' => $row->supplier_number,
            'branchId' => $row->branch_id ? (int) $row->branch_id : null,
            'branchName' => $row->branch_name,
            'invoiceDate' => $row->invoice_date,
            'dueDate' => $row->due_date,
            'paymentTerms' => $row->payment_terms ?: 'credit',
            'paymentReference' => $row->payment_reference,
            'invoiceType' => $row->invoice_type,
            'invoiceTypeId' => $row->invoice_type_id ? (int) $row->invoice_type_id : null,
            'invoiceTypeName' => $row->configured_type_name,
            'invoiceGroupName' => $row->invoice_group_name,
            'postingBehavior' => $row->configured_posting_behavior ?? $row->invoice_type,
            'isPostable' => $row->invoice_type_id ? (bool) $row->configured_is_postable : true,
            'expenseCategoryId' => $row->expense_category_id ? (int) $row->expense_category_id : null,
            'expenseCategoryName' => $row->expense_category_name,
            'debitAccountId' => (int) $row->debit_account_id,
            'debitAccountCode' => $row->debit_account_code,
            'debitAccountName' => $row->debit_account_name,
            'subtotal' => Money::decimal(Money::cents($row->subtotal)),
            'taxAmount' => Money::decimal(Money::cents($row->tax_amount)),
            'discountType' => $row->discount_type,
            'discountValue' => $row->discount_value,
            'discountAmount' => Money::decimal(Money::cents($row->discount_amount)),
            'chargesAmount' => Money::decimal(Money::cents($row->charges_amount)),
            'totalAmount' => Money::decimal(Money::cents($row->total_amount)),
            'factoryCurrency' => \App\Support\FactoryCurrency::snapshot($row),
            'remainingAmount' => number_format($remaining / 100, 2, '.', ''),
            'status' => $row->status,
            'isOverdue' => $isOverdue,
            'description' => $row->description,
            'notes' => $row->notes,
            'journalEntryId' => $row->journal_entry_id ? (int) $row->journal_entry_id : null,
            'reversalJournalEntryId' => $row->reversal_journal_entry_id ? (int) $row->reversal_journal_entry_id : null,
            'postedAt' => $row->posted_at,
            'createdAt' => $row->created_at,
            'backdateReason' => $row->backdate_reason,
            'isBackdated' => $row->invoice_date < substr((string) $row->created_at, 0, 10),
        ];
    }
}
