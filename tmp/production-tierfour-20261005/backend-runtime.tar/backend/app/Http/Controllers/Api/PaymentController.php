<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\OrderLifecycleException;
use App\Http\Controllers\Controller;
use App\Services\AccountingPostingService;
use App\Services\BranchAccessService;
use App\Services\DiscountEligibilityService;
use App\Services\OperationalAuditService;
use App\Services\OrderLifecyclePolicy;
use App\Services\PartyAccountService;
use App\Services\PosPricingService;
use App\Services\PosCashLocationResolver;
use App\Services\SaleConsumptionService;
use App\Services\ShiftLockService;
use App\Support\BranchLocalDate;
use App\Support\Money;
use App\Support\PaymentPerformanceProbe;
use App\Support\SalePaymentMethodResolver;
use App\Support\TenantContext;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PaymentController extends Controller
{
    public function __construct(
        private readonly OrderLifecyclePolicy $lifecycle,
        private readonly DiscountEligibilityService $discounts,
        private readonly PosPricingService $pricing,
        private readonly AccountingPostingService $posting,
        private readonly OperationalAuditService $audit,
        private readonly SaleConsumptionService $consumption,
        private readonly PaymentPerformanceProbe $performance,
        private readonly PosCashLocationResolver $cashLocations,
        private readonly ShiftLockService $shiftLocks,
        private readonly PartyAccountService $partyAccounts,
        private readonly \App\Services\FinanceAccountMap $accountMap,
        private readonly \App\Services\DeliveryCompanyCustomerService $deliveryCustomers,
    ) {}

    /** The payment types Finance has actually configured and activated (the single source for what a cashier may offer). */
    private function availableMethodTypes(int $tenantId, bool $identifiedCustomer): \Illuminate\Support\Collection
    {
        $methods = DB::table('payment_methods as pm')
            ->join('financial_accounts as accounts', 'accounts.id', '=', 'pm.financial_account_id')
            ->where('pm.tenant_id', $tenantId)->where('pm.is_active', true)
            ->where('accounts.tenant_id', $tenantId)->where('accounts.is_active', true)->whereNull('accounts.deleted_at')
            ->whereIn('pm.type', ['cash', 'card', 'wallet', 'sham_cash'])
            ->orderBy('pm.sort_order')->orderBy('pm.id')->pluck('pm.type')
            ->unique()->values();

        return $identifiedCustomer ? $methods : $methods->reject(fn ($type) => $type === 'wallet')->values();
    }

    private function isIdentifiedCustomer(int $tenantId, int $customerId): bool
    {
        return DB::table('customers')->where('tenant_id', $tenantId)->where('id', $customerId)
            ->where('is_active', true)->where('is_walk_in', false)->whereNull('deleted_at')->exists();
    }

    /** Methods offered before the order exists on the server (published-menu carts are created at payment time). */
    public function availableMethods(Request $request): JsonResponse
    {
        $data = $request->validate(['customerId' => ['nullable', 'integer']]);
        $tenantId = TenantContext::id($request);
        $identified = isset($data['customerId']) && $this->isIdentifiedCustomer($tenantId, (int) $data['customerId']);

        return response()->json(['data' => ['methods' => $this->availableMethodTypes($tenantId, $identified)]]);
    }

    public function summary(Request $request, int $order): JsonResponse
    {
        $data = $request->validate(['amountReceived' => ['nullable', 'numeric', 'min:0']]);
        $tenantId = TenantContext::id($request);
        $row = $this->findOrder($request, $tenantId, $order);
        $itemCount = (float) DB::table('order_items')->where('tenant_id', $tenantId)->where('order_id', $order)->whereNull('deleted_at')->sum('quantity');
        $total = (float) $row->total;
        $paymentStatus = (string) $row->payment_status;
        $orderStatus = (string) $row->status;
        $completedPaymentExists = DB::table('payments')
            ->where('tenant_id', $tenantId)
            ->where('order_id', $order)
            ->where('status', 'completed')
            ->whereNull('deleted_at')
            ->exists();
        $outstandingAmount = $completedPaymentExists
            ? 0.0
            : max(0, round($total, 2));
        $received = array_key_exists('amountReceived', $data) ? (float) $data['amountReceived'] : $total;
        $actorId = (int) $request->attributes->get('auth_user')->id;
        $hasOpenShift = $row->shift_id !== null && DB::table('shifts')
            ->where('tenant_id', $tenantId)
            ->where('id', $row->shift_id)
            ->where('branch_id', $row->branch_id)
            ->where('user_id', $actorId)
            ->where('status', 'open')
            ->whereNull('deleted_at')
            ->exists();
        $lifecycleCanPay = $this->lifecycle->canPay($row);
        $warehouseBlocker = $lifecycleCanPay
            ? $this->consumption->preflightWarehouseConfiguration($tenantId, $row)
            : null;
        // The wallet is the customer's own account: offered only when the order belongs to a real customer.
        $hasIdentifiedCustomer = $row->customer_id && $this->isIdentifiedCustomer($tenantId, (int) $row->customer_id);
        $methods = $this->availableMethodTypes($tenantId, (bool) $hasIdentifiedCustomer);
        $isZeroBalanceCompletion = Money::cents($total) === 0 && $itemCount > 0;
        $canPay = $lifecycleCanPay &&
            ! $completedPaymentExists &&
            ($isZeroBalanceCompletion || ($outstandingAmount > 0 && $methods->isNotEmpty())) &&
            $hasOpenShift &&
            $warehouseBlocker === null;
        $blockedReason = $canPay
            ? null
            : ($completedPaymentExists || $paymentStatus === 'paid'
                ? 'A completed payment already exists for this order.'
                : ($warehouseBlocker['reason'] ?? (! $hasOpenShift
                    ? 'No open shift found. Open a shift before paying.'
                    : (! $isZeroBalanceCompletion && $methods->isEmpty()
                        ? 'No supported payment method is available for this order.'
                        : 'This order cannot be paid in its current state.'))));
        $blockerCode = $canPay ? null : ($warehouseBlocker['code'] ?? null);

        return response()->json(['data' => [
            'orderId' => $row->id, 'orderNumber' => $row->order_number, 'totalDue' => $total,
            'outstandingAmount' => $outstandingAmount, 'itemCount' => $itemCount,
            'orderStatus' => $orderStatus, 'paymentStatus' => $paymentStatus,
            'canPay' => $canPay, 'blockedReason' => $blockedReason,
            'blockerCode' => $blockerCode,
            'completedPaymentExists' => $completedPaymentExists,
            'amountReceived' => $received,
            'changeDue' => round(max(0, $received - $total), 2),
            'methods' => $methods, 'quickAmounts' => $this->quickAmounts($total),
        ]]);
    }

    public function pay(Request $request, int $order): JsonResponse
    {
        $this->performance->controllerStarted();
        $data = $request->validate([
            // A zero-balance order is completed without a tender. Keep the
            // normal tender contract strict below once totals are recalculated.
            'method' => ['nullable', 'in:cash,card,wallet,sham_cash,split'],
            'paymentMethodId' => ['nullable', 'integer'],
            'amount' => ['required', 'numeric', 'min:0'],
            'reference' => ['nullable', 'string'], 'note' => ['nullable', 'string'],
            'idempotencyKey' => ['required', 'string', 'max:120'],
            // The order type is chosen in the payment dialog. A delivery order is settled through a delivery company.
            'orderType' => ['nullable', 'in:dine_in,takeaway,delivery'],
            'deliveryCompanyId' => ['nullable', 'integer'],
            // Delivery only: leave the amount on the delivery company's account (settled later) instead of cash now.
            'onDeliveryAccount' => ['nullable', 'boolean'],
        ]);
        $tenantId = TenantContext::id($request);
        $hash = $this->payloadHash($data);

        $actorId = (int) $request->attributes->get('auth_user')->id;
        $transactionStarted = microtime(true);
        $closureEndedAt = null;
        $result = DB::transaction(function () use ($request, $tenantId, $order, $data, $hash, $actorId, &$closureEndedAt): array {
            $row = $this->performance->measure('order locking', fn () => $this->lockedOrder($request, $tenantId, $order));
            $existing = DB::table('payments')->where('tenant_id', $tenantId)
                ->where('idempotency_key', $data['idempotencyKey'])->first();
            if ($existing) {
                if ((int) $existing->order_id !== (int) $row->id || ! hash_equals((string) $existing->idempotency_hash, $hash)) {
                    throw new OrderLifecycleException('PAYMENT_IDEMPOTENCY_CONFLICT', 'This payment key was already used for a different request.');
                }

                return ['payment' => $existing, 'total' => (float) $row->total, 'received' => (float) $data['amount']];
            }

            $this->lifecycle->assertPayable($row);
            $this->performance->measure('shift validation', fn () => $this->assertActorHasOpenShift($tenantId, $row, $actorId));
            if (DB::table('payments')->where('tenant_id', $tenantId)->where('order_id', $row->id)->where('status', 'completed')->whereNull('deleted_at')->exists()) {
                throw new OrderLifecycleException('PAYMENT_ALREADY_COMPLETED', 'A completed payment already exists for this order.');
            }
            $row = $this->consumption->bindLegacyOrderWarehouse($tenantId, $row);
            // The driver hands the cash over on delivery, so a delivery order is paid like any other
            // sale (cash goes to the drawer); the company is only recorded on the order for reporting.
            $deliveryMethod = null;
            if (($data['orderType'] ?? null) !== null) {
                $deliveryMethod = $this->applyOrderType($tenantId, $row, $data);
                $row = $this->lockedOrder($request, $tenantId, $order);
            }
            $onAccount = (bool) ($data['onDeliveryAccount'] ?? false);
            if ($onAccount && $deliveryMethod === null) {
                throw ValidationException::withMessages(['onDeliveryAccount' => 'اختر شركة التوصيل لتسجيل الطلب آجلاً على حسابها.']);
            }
            // Apply-time deliberately defers tender validation. Payment is the
            // authoritative second stage, including revalidation after a
            // manager changes a policy or its schedule expires.
            if (DB::table('order_discounts')->where('tenant_id', $tenantId)->where('order_id', $row->id)->whereNotNull('discount_id')->exists()) {
                $row = $this->pricing->recalculateOrder($tenantId, $row->id, true);
            }
            $zeroBalance = Money::cents($row->total) === 0;
            $resolvedMethod = null;
            if (! $zeroBalance && $onAccount) {
                // Deferred settlement: the sale debits the account the manager linked to the delivery company
                // (it owes the café); nothing enters the drawer. No customer tender is involved.
                $resolvedMethod = $deliveryMethod;
            } elseif (! $zeroBalance) {
                // A configured payment method is authoritative for both
                // Discount eligibility and Finance posting. The legacy method
                // remains a compatibility selector only when no ID is sent.
                if (($data['method'] ?? null) === null) {
                    throw ValidationException::withMessages(['method' => 'A payment method is required when an amount is due.']);
                }
                $resolvedMethod = array_key_exists('paymentMethodId', $data) && $data['paymentMethodId'] !== null
                    ? SalePaymentMethodResolver::resolveExplicit($tenantId, (int) $data['paymentMethodId'])
                    : SalePaymentMethodResolver::resolveByLegacyMethod($tenantId, $data['method']);
                if ($resolvedMethod === null) {
                    throw new OrderLifecycleException('PAYMENT_METHOD_INVALID', 'The selected payment method is not active or has no valid Finance account mapping.');
                }
                if ($resolvedMethod->type !== $data['method']) {
                    throw ValidationException::withMessages(['paymentMethodId' => 'The selected payment method does not match method.']);
                }
                if ($resolvedMethod->type === 'wallet'
                    && $this->partyAccounts->codeForOrderCustomer($tenantId, $row->customer_id, $actorId) === null) {
                    throw ValidationException::withMessages(['paymentMethodId' => 'الدفع من المحفظة يتطلب ربط الطلب بعميل مسجّل.']);
                }
                if ($resolvedMethod->type === 'wallet' && $row->customer_id) {
                    // The wallet pays only from funds the customer holds plus the limit the owner set for them.
                    $wallet = $this->partyAccounts->walletState($tenantId, (int) $row->customer_id, lock: true);
                    if (\App\Support\Money::cents((string) $row->total) > $wallet['availableCents']) {
                        throw ValidationException::withMessages(['paymentMethodId' => 'رصيد محفظة العميل (مع حد الائتمان) لا يكفي لهذا المبلغ. المتاح: '.\App\Support\Money::decimal(max(0, $wallet['availableCents'])).'.']);
                    }
                }
                if ($resolvedMethod->type === 'sham_cash' && trim((string) ($data['reference'] ?? '')) === '') {
                    throw ValidationException::withMessages(['reference' => 'أدخل رقم عملية الشام كاش.']);
                }
                if (DB::table('order_discounts')->where('tenant_id', $tenantId)->where('order_id', $row->id)->whereNotNull('discount_id')->exists()) {
                    $row = $this->pricing->recalculateOrder($tenantId, $row->id, true, $resolvedMethod->paymentMethodId, $resolvedMethod->type);
                }
            }
            if ((float) $data['amount'] < (float) $row->total) {
                throw ValidationException::withMessages(['amount' => 'Payment amount is less than order total.']);
            }

            $currency = (string) (DB::table('branches')->where('tenant_id', $tenantId)->where('id', $row->branch_id)->whereNull('deleted_at')->value('currency') ?? 'SYP');
            $now = now();
            $persistenceStarted = $this->performance->start('payment persistence');
            $paymentId = DB::table('payments')->insertGetId([
                'tenant_id' => $tenantId, 'branch_id' => $row->branch_id, 'order_id' => $row->id,
                'shift_id' => $row->shift_id, 'cashier_id' => $actorId,
                // This is a completion marker, not a cash/card tender.
                'method' => $zeroBalance ? 'zero_balance' : $resolvedMethod->type,
                'amount' => $row->total, 'currency' => $currency, 'status' => 'completed',
                'payment_method_id' => $zeroBalance ? null : $resolvedMethod->paymentMethodId,
                'idempotency_key' => $data['idempotencyKey'], 'idempotency_hash' => $hash,
                'reference_number' => $data['reference'] ?? null, 'notes' => $data['note'] ?? null,
                'paid_at' => $now, 'created_at' => $now, 'updated_at' => $now,
            ]);
            $this->discounts->consumeUsage($tenantId, $row, $paymentId);
            DB::table('orders')->where('tenant_id', $tenantId)->where('id', $row->id)->update([
                'status' => 'paid', 'payment_status' => 'paid', 'closed_at' => $now, 'updated_at' => $now,
            ]);
            $this->performance->stop('payment persistence', $persistenceStarted);

            $consumption = $this->consumption->consumeForOrder($request, $tenantId, $row, $paymentId, $actorId);
            $this->performance->measure('accounting posting', fn () => $this->postSale($request, $tenantId, $row, $resolvedMethod, $consumption['cogsTotalCents'], $actorId));

            $answer = ['payment' => DB::table('payments')->where('id', $paymentId)->first(), 'total' => (float) $row->total, 'received' => (float) $data['amount']];
            $closureEndedAt = microtime(true);

            return $answer;
        }, 3);
        $this->performance->stop('transaction commit', $closureEndedAt ?? $transactionStarted);

        return response()->json(['data' => $this->serializePayment($order, $result['payment'], $result['total'], $result['received'])]);
    }

    /** Delivery companies the cashier may pick: active `delivery_app` payment methods with a valid ledger account. */
    public function deliveryCompanies(Request $request): JsonResponse
    {
        $tenantId = TenantContext::id($request);
        $rows = DB::table('payment_methods as pm')
            ->join('financial_accounts as accounts', 'accounts.id', '=', 'pm.financial_account_id')
            ->where('pm.tenant_id', $tenantId)->where('pm.is_active', true)->where('pm.type', 'delivery_app')
            ->where('accounts.tenant_id', $tenantId)->where('accounts.is_active', true)->whereNull('accounts.deleted_at')
            ->orderBy('pm.sort_order')->orderBy('pm.id')
            ->get(['pm.id', 'pm.name', 'pm.code']);

        return response()->json(['data' => $rows->map(fn ($row) => ['id' => (int) $row->id, 'name' => $row->name, 'code' => $row->code])->values()]);
    }

    /**
     * Persists the order type chosen in the payment dialog. A delivery order may name the delivery
     * company it came through (optional: the café's own delivery has none).
     */
    private function applyOrderType(int $tenantId, object $row, array $data): ?object
    {
        $type = $data['orderType'] ?? null;
        $companyId = $data['deliveryCompanyId'] ?? null;
        $method = null;
        if ($type === 'delivery') {
            if ($companyId !== null) {
                $method = SalePaymentMethodResolver::resolveById($tenantId, (int) $companyId);
                if ($method === null || $method->type !== 'delivery_app') {
                    throw ValidationException::withMessages(['deliveryCompanyId' => 'شركة التوصيل غير مفعّلة أو غير مرتبطة بحساب.']);
                }
            }
        } elseif ($companyId !== null) {
            throw ValidationException::withMessages(['deliveryCompanyId' => 'شركة التوصيل تُحدَّد لطلبات التوصيل فقط.']);
        }
        DB::table('orders')->where('tenant_id', $tenantId)->where('id', $row->id)->update([
            'type' => $type, 'delivery_company_id' => $method?->paymentMethodId, 'updated_at' => now(),
        ]);

        return $method;
    }

    private function lockedOrder(Request $request, int $tenantId, int $order): object
    {
        $row = DB::table('orders')->where('tenant_id', $tenantId)->where('id', $order)->whereNull('deleted_at')->lockForUpdate()->first();
        abort_if(! $row, 404, 'Order not found.');
        app(BranchAccessService::class)->authorizeRequestBranch($request, (int) $row->branch_id);

        return $row;
    }

    private function findOrder(Request $request, int $tenantId, int $order): object
    {
        $row = DB::table('orders')->where('tenant_id', $tenantId)->where('id', $order)->whereNull('deleted_at')->first();
        abort_if(! $row, 404, 'Order not found.');
        app(BranchAccessService::class)->authorizeRequestBranch($request, (int) $row->branch_id);

        return $row;
    }

    private function serializePayment(int $orderId, object $payment, float $total, float $received): array
    {
        return ['orderId' => $orderId, 'changeDue' => round(max(0, $received - $total), 2), 'payment' => [
            'id' => $payment->id, 'method' => $payment->method, 'amount' => (float) $payment->amount,
            'status' => $payment->status, 'reference' => $payment->reference_number,
            'idempotencyKey' => $payment->idempotency_key, 'paidAt' => $payment->paid_at,
        ]];
    }

    /**
     * Acquires a shared row lock on the order's shift, held for the rest of
     * this transaction (H1). This is what stops the shift being observed as
     * "open" here after shifts:reconcile-overlap has already exclusively
     * locked it to close it: the reconciliation's FOR UPDATE either blocks
     * until this transaction commits, or this lock blocks until reconciliation
     * commits and this SELECT then sees the shift already closed.
     */
    private function assertActorHasOpenShift(int $tenantId, object $order, int $actorId): void
    {
        if ($order->shift_id === null) {
            throw ValidationException::withMessages([
                'shiftId' => 'No open shift found. Open a shift before paying.',
            ]);
        }
        try {
            $this->shiftLocks->sharedOpenShift($tenantId, (int) $order->shift_id, (int) $order->branch_id, $actorId);
        } catch (ValidationException) {
            throw ValidationException::withMessages([
                'shiftId' => 'No open shift found. Open a shift before paying.',
            ]);
        }
    }

    private function payloadHash(array $data): string
    {
        return hash('sha256', json_encode([
            'method' => $data['method'] ?? null, 'amount' => (string) $data['amount'],
            'paymentMethodId' => $data['paymentMethodId'] ?? null,
            'reference' => $data['reference'] ?? null, 'note' => $data['note'] ?? null,
            'orderType' => $data['orderType'] ?? null, 'deliveryCompanyId' => $data['deliveryCompanyId'] ?? null,
            'onDeliveryAccount' => (bool) ($data['onDeliveryAccount'] ?? false),
        ], JSON_THROW_ON_ERROR));
    }

    private function postSale(Request $request, int $tenantId, object $order, ?object $method, int $cogsCents, int $actorId): void
    {
        $subtotal = Money::cents($order->subtotal);
        $discount = Money::cents($order->discount_total);
        $tax = Money::cents($order->tax_total);
        $total = Money::cents($order->total);
        // A zero-balance completion deliberately has no tender line. Its
        // discount debit offsets revenue; inventory/COGS stays balanced too.
        $lines = [];
        $partyCode = $method !== null && $total > 0
            ? $this->partyAccounts->codeForOrderCustomer($tenantId, $order->customer_id, $actorId)
            : null;
        $walletSale = $method?->type === 'wallet' && $partyCode !== null;
        if ($method !== null) {
            // A wallet payment is settled from the customer's own single account (their balance / receivable).
            $tender = ['accountCode' => $walletSale ? $partyCode : $method->accountCode, 'debit' => Money::decimal($total)];
            if ($walletSale) {
                $tender['description'] = "دفع من محفظة العميل — طلب رقم {$order->order_number}";
            }
            if ($method->type === 'cash') {
                $tender['accountCode'] = $this->cashLocations->accountForSale($tenantId, $order);
                $tender['financialLocationId'] = $this->cashLocations->forSale($tenantId, $order, $tender['accountCode']);
            } elseif ($method->type === 'sham_cash' && ($method->financialLocationId ?? null) !== null) {
                $tender['financialLocationId'] = $method->financialLocationId;
            }
            $lines[] = $tender;
        }
        // An identified customer (a supplier is also a customer) gets the sale and the till
        // collection on the person's own single account: net zero, but fully visible in its ledger.
        if ($partyCode !== null && ! $walletSale) {
            $lines[] = ['accountCode' => $partyCode, 'debit' => Money::decimal($total), 'description' => "بيع نقطة البيع — طلب رقم {$order->order_number}"];
            $lines[] = ['accountCode' => $partyCode, 'credit' => Money::decimal($total), 'description' => "تحصيل عند الدفع — طلب رقم {$order->order_number}"];
        }
        // A delivery-company order settled in cash by the driver also appears on the company's own
        // account (sale + collection, net zero) so that account shows every order it brought.
        // An order left on the company's account already debits that account as its tender line.
        $companyCode = $method !== null && $total > 0 && ($method->type ?? null) !== 'delivery_app'
            ? $this->deliveryCustomers->accountCodeForOrder($tenantId, $order)
            : null;
        if ($companyCode !== null) {
            $lines[] = ['accountCode' => $companyCode, 'debit' => Money::decimal($total), 'description' => "بيع توصيل — طلب رقم {$order->order_number}"];
            $lines[] = ['accountCode' => $companyCode, 'credit' => Money::decimal($total), 'description' => "تحصيل نقدي من السائق — طلب رقم {$order->order_number}"];
        }
        if ($discount > 0) {
            $lines[] = ['accountCode' => $this->accountMap->code($tenantId, 'sales.discount_given'), 'debit' => Money::decimal($discount)];
        }
        $lines[] = ['accountCode' => $this->accountMap->code($tenantId, 'sales.revenue'), 'credit' => Money::decimal($subtotal)];
        if ($tax > 0) {
            $lines[] = ['accountCode' => $this->accountMap->code($tenantId, 'sales.tax_payable'), 'credit' => Money::decimal($tax)];
        }
        if ($cogsCents > 0) {
            $lines[] = ['accountCode' => $this->accountMap->code($tenantId, 'sales.cost_of_goods_sold'), 'debit' => Money::decimal($cogsCents)];
            $lines[] = ['accountCode' => $this->accountMap->code($tenantId, 'sales.inventory_asset'), 'credit' => Money::decimal($cogsCents)];
        }

        $this->posting->postSale($request, $tenantId, [
            'branchId' => $order->branch_id,
            'sourceId' => $order->id,
            'sourceEvent' => 'POS_ORDER_PAID',
            'entryDate' => BranchLocalDate::today($order->branch_id ? (int) $order->branch_id : null),
            'description' => "بيع نقطة البيع — طلب رقم {$order->order_number}",
            'lines' => $lines,
        ], $actorId);
    }

    private function quickAmounts(float $total): array
    {
        $rounded = (float) (ceil($total / 5) * 5);

        return array_values(array_unique([$rounded, $rounded + 5, $rounded + 15, $total]));
    }
}
